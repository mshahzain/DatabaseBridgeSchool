﻿namespace TheBridgeSchool
{
    partial class NewSalaryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.UnpaidRadioButton = new System.Windows.Forms.RadioButton();
            this.PaidRadioButton = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.NetAmountTextBox = new System.Windows.Forms.TextBox();
            this.InitialSalaryTextBox = new System.Windows.Forms.TextBox();
            this.NameComboBox = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.AdditionsTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.LateSalaryTextBox = new System.Windows.Forms.TextBox();
            this.AttendanceBonusTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.YearComboBox = new System.Windows.Forms.ComboBox();
            this.MonthComboBox = new System.Windows.Forms.ComboBox();
            this.DeadlinesNotMetTextBox = new System.Windows.Forms.TextBox();
            this.AbsencePenaltyTextBox = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.DeductionsTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.GratuityTextBox = new System.Windows.Forms.TextBox();
            this.AdvanceTakenTextBox = new System.Windows.Forms.TextBox();
            this.SaveButton = new System.Windows.Forms.Button();
            this.CancellingButton = new System.Windows.Forms.Button();
            this.GoBackButton = new System.Windows.Forms.Button();
            this.UpdateButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.NetAmountTextBox);
            this.groupBox1.Controls.Add(this.InitialSalaryTextBox);
            this.groupBox1.Controls.Add(this.NameComboBox);
            this.groupBox1.Location = new System.Drawing.Point(12, 58);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(296, 269);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Basic Info";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.UnpaidRadioButton);
            this.groupBox4.Controls.Add(this.PaidRadioButton);
            this.groupBox4.Location = new System.Drawing.Point(15, 158);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(259, 93);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Payment Status:";
            // 
            // UnpaidRadioButton
            // 
            this.UnpaidRadioButton.AutoSize = true;
            this.UnpaidRadioButton.Location = new System.Drawing.Point(158, 42);
            this.UnpaidRadioButton.Name = "UnpaidRadioButton";
            this.UnpaidRadioButton.Size = new System.Drawing.Size(72, 17);
            this.UnpaidRadioButton.TabIndex = 1;
            this.UnpaidRadioButton.TabStop = true;
            this.UnpaidRadioButton.Text = "Not Paid";
            this.UnpaidRadioButton.UseVisualStyleBackColor = true;
            // 
            // PaidRadioButton
            // 
            this.PaidRadioButton.AutoSize = true;
            this.PaidRadioButton.Location = new System.Drawing.Point(48, 42);
            this.PaidRadioButton.Name = "PaidRadioButton";
            this.PaidRadioButton.Size = new System.Drawing.Size(49, 17);
            this.PaidRadioButton.TabIndex = 0;
            this.PaidRadioButton.TabStop = true;
            this.PaidRadioButton.Text = "Paid";
            this.PaidRadioButton.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 115);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "NetAmount:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Salary:";
            // 
            // NetAmountTextBox
            // 
            this.NetAmountTextBox.Enabled = false;
            this.NetAmountTextBox.Location = new System.Drawing.Point(116, 112);
            this.NetAmountTextBox.Name = "NetAmountTextBox";
            this.NetAmountTextBox.Size = new System.Drawing.Size(149, 20);
            this.NetAmountTextBox.TabIndex = 2;
            // 
            // InitialSalaryTextBox
            // 
            this.InitialSalaryTextBox.Location = new System.Drawing.Point(116, 58);
            this.InitialSalaryTextBox.Name = "InitialSalaryTextBox";
            this.InitialSalaryTextBox.Size = new System.Drawing.Size(149, 20);
            this.InitialSalaryTextBox.TabIndex = 1;
            this.InitialSalaryTextBox.TextChanged += new System.EventHandler(this.InitialSalaryTextBox_TextChanged);
            // 
            // NameComboBox
            // 
            this.NameComboBox.FormattingEnabled = true;
            this.NameComboBox.Location = new System.Drawing.Point(116, 23);
            this.NameComboBox.Name = "NameComboBox";
            this.NameComboBox.Size = new System.Drawing.Size(149, 21);
            this.NameComboBox.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.AdditionsTextBox);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.LateSalaryTextBox);
            this.groupBox2.Controls.Add(this.AttendanceBonusTextBox);
            this.groupBox2.Location = new System.Drawing.Point(314, 58);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(296, 113);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Additons:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(36, 83);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Total Addition: ";
            // 
            // AdditionsTextBox
            // 
            this.AdditionsTextBox.Enabled = false;
            this.AdditionsTextBox.Location = new System.Drawing.Point(135, 76);
            this.AdditionsTextBox.Name = "AdditionsTextBox";
            this.AdditionsTextBox.Size = new System.Drawing.Size(155, 20);
            this.AdditionsTextBox.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(52, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Late Salary:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Attendance Bonus:";
            // 
            // LateSalaryTextBox
            // 
            this.LateSalaryTextBox.Location = new System.Drawing.Point(135, 50);
            this.LateSalaryTextBox.Name = "LateSalaryTextBox";
            this.LateSalaryTextBox.Size = new System.Drawing.Size(155, 20);
            this.LateSalaryTextBox.TabIndex = 1;
            this.LateSalaryTextBox.TextChanged += new System.EventHandler(this.AttendanceBonusTextBox_TextChanged);
            // 
            // AttendanceBonusTextBox
            // 
            this.AttendanceBonusTextBox.Location = new System.Drawing.Point(135, 24);
            this.AttendanceBonusTextBox.Name = "AttendanceBonusTextBox";
            this.AttendanceBonusTextBox.Size = new System.Drawing.Size(155, 20);
            this.AttendanceBonusTextBox.TabIndex = 0;
            this.AttendanceBonusTextBox.TextChanged += new System.EventHandler(this.AttendanceBonusTextBox_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(335, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Year:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(125, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Month:";
            // 
            // YearComboBox
            // 
            this.YearComboBox.FormattingEnabled = true;
            this.YearComboBox.Items.AddRange(new object[] {
            "2018",
            "2019",
            "2020",
            "2021",
            "2022"});
            this.YearComboBox.Location = new System.Drawing.Point(378, 31);
            this.YearComboBox.Name = "YearComboBox";
            this.YearComboBox.Size = new System.Drawing.Size(80, 21);
            this.YearComboBox.TabIndex = 1;
            // 
            // MonthComboBox
            // 
            this.MonthComboBox.FormattingEnabled = true;
            this.MonthComboBox.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.MonthComboBox.Location = new System.Drawing.Point(177, 31);
            this.MonthComboBox.Name = "MonthComboBox";
            this.MonthComboBox.Size = new System.Drawing.Size(131, 21);
            this.MonthComboBox.TabIndex = 0;
            // 
            // DeadlinesNotMetTextBox
            // 
            this.DeadlinesNotMetTextBox.Location = new System.Drawing.Point(135, 91);
            this.DeadlinesNotMetTextBox.Name = "DeadlinesNotMetTextBox";
            this.DeadlinesNotMetTextBox.Size = new System.Drawing.Size(155, 20);
            this.DeadlinesNotMetTextBox.TabIndex = 3;
            this.DeadlinesNotMetTextBox.TextChanged += new System.EventHandler(this.AbsencePenaltyTextBox_TextChanged);
            // 
            // AbsencePenaltyTextBox
            // 
            this.AbsencePenaltyTextBox.Location = new System.Drawing.Point(135, 13);
            this.AbsencePenaltyTextBox.Name = "AbsencePenaltyTextBox";
            this.AbsencePenaltyTextBox.Size = new System.Drawing.Size(155, 20);
            this.AbsencePenaltyTextBox.TabIndex = 0;
            this.AbsencePenaltyTextBox.TextChanged += new System.EventHandler(this.AbsencePenaltyTextBox_TextChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.DeductionsTextBox);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.GratuityTextBox);
            this.groupBox3.Controls.Add(this.AbsencePenaltyTextBox);
            this.groupBox3.Controls.Add(this.DeadlinesNotMetTextBox);
            this.groupBox3.Controls.Add(this.AdvanceTakenTextBox);
            this.groupBox3.Location = new System.Drawing.Point(314, 177);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(296, 150);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Deductions:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(29, 124);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 13);
            this.label13.TabIndex = 21;
            this.label13.Text = "Total Deduction:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(71, 72);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "Gratuity:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 46);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "Advance Taken:";
            // 
            // DeductionsTextBox
            // 
            this.DeductionsTextBox.Enabled = false;
            this.DeductionsTextBox.Location = new System.Drawing.Point(135, 117);
            this.DeductionsTextBox.Name = "DeductionsTextBox";
            this.DeductionsTextBox.Size = new System.Drawing.Size(155, 20);
            this.DeductionsTextBox.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 98);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(115, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Deadlines Not Met:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Absence Penalty:";
            // 
            // GratuityTextBox
            // 
            this.GratuityTextBox.Location = new System.Drawing.Point(135, 65);
            this.GratuityTextBox.Name = "GratuityTextBox";
            this.GratuityTextBox.Size = new System.Drawing.Size(155, 20);
            this.GratuityTextBox.TabIndex = 2;
            this.GratuityTextBox.TextChanged += new System.EventHandler(this.AbsencePenaltyTextBox_TextChanged);
            // 
            // AdvanceTakenTextBox
            // 
            this.AdvanceTakenTextBox.Location = new System.Drawing.Point(135, 39);
            this.AdvanceTakenTextBox.Name = "AdvanceTakenTextBox";
            this.AdvanceTakenTextBox.Size = new System.Drawing.Size(155, 20);
            this.AdvanceTakenTextBox.TabIndex = 1;
            this.AdvanceTakenTextBox.TextChanged += new System.EventHandler(this.AbsencePenaltyTextBox_TextChanged);
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(489, 333);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(121, 27);
            this.SaveButton.TabIndex = 16;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // CancellingButton
            // 
            this.CancellingButton.Location = new System.Drawing.Point(362, 333);
            this.CancellingButton.Name = "CancellingButton";
            this.CancellingButton.Size = new System.Drawing.Size(121, 27);
            this.CancellingButton.TabIndex = 17;
            this.CancellingButton.Text = "Cancel";
            this.CancellingButton.UseVisualStyleBackColor = true;
            this.CancellingButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // GoBackButton
            // 
            this.GoBackButton.Location = new System.Drawing.Point(11, 335);
            this.GoBackButton.Name = "GoBackButton";
            this.GoBackButton.Size = new System.Drawing.Size(113, 25);
            this.GoBackButton.TabIndex = 18;
            this.GoBackButton.Text = "Back";
            this.GoBackButton.UseVisualStyleBackColor = true;
            this.GoBackButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // UpdateButton
            // 
            this.UpdateButton.Location = new System.Drawing.Point(489, 333);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(121, 27);
            this.UpdateButton.TabIndex = 19;
            this.UpdateButton.Text = "Update";
            this.UpdateButton.UseVisualStyleBackColor = true;
            this.UpdateButton.Visible = false;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // NewSalaryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 372);
            this.Controls.Add(this.UpdateButton);
            this.Controls.Add(this.GoBackButton);
            this.Controls.Add(this.CancellingButton);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.YearComboBox);
            this.Controls.Add(this.MonthComboBox);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Maroon;
            this.Name = "NewSalaryForm";
            this.Text = "Add New Salary";
            this.Load += new System.EventHandler(this.NewSalaryForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox NameComboBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox YearComboBox;
        private System.Windows.Forms.ComboBox MonthComboBox;
        private System.Windows.Forms.TextBox LateSalaryTextBox;
        private System.Windows.Forms.TextBox AttendanceBonusTextBox;
        private System.Windows.Forms.TextBox DeadlinesNotMetTextBox;
        private System.Windows.Forms.TextBox AbsencePenaltyTextBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton UnpaidRadioButton;
        private System.Windows.Forms.RadioButton PaidRadioButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox NetAmountTextBox;
        private System.Windows.Forms.TextBox InitialSalaryTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox GratuityTextBox;
        private System.Windows.Forms.TextBox AdvanceTakenTextBox;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button CancellingButton;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox AdditionsTextBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox DeductionsTextBox;
        private System.Windows.Forms.Button GoBackButton;
        private System.Windows.Forms.Button UpdateButton;
    }
}