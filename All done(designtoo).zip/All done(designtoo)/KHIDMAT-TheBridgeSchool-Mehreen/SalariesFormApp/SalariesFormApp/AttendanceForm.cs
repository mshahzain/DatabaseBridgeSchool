﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TheBridgeSchool
{
    public partial class AttendanceForm : Form
    {
        string Desig = " ";

        public AttendanceForm()
        {
            InitializeComponent();
        }

        private string GradeValue(string gradeName)
        {
            string shortForm = "";
            if (gradeName == "Play Group")
            {
                shortForm = "PG";
            }
            else if (gradeName == "Lower Nursery")
            {
                shortForm = "LNY";
            }
            else if (gradeName == "Lower Nursery B")
            {
                shortForm = "LNB";
            }
            else if (gradeName == "1A")
            {
                shortForm = "1A";
            }
            else if (gradeName == "1B")
            {
                shortForm = "1B";
            }
            else if (gradeName == "2nd")
            {
                shortForm = "2A";
            }
            else if (gradeName == "3rd")
            {
                shortForm = "3A";
            }
            else if (gradeName == "4th")
            {
                shortForm = "4A";
            }
            else if (gradeName == "5th")
            {
                shortForm = "5A";
            }
            else if (gradeName == "6th")
            {
                shortForm = "6A";
            }
            else if (gradeName == "7th")
            {
                shortForm = "7A";
            }
            else if (gradeName == "8th")
            {
                shortForm = "8A";
            }
            return shortForm;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            GradeComboBox.Enabled = false;
            Desig = "Teacher";
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            GradeComboBox.Enabled = true;
            Desig = "Student";
        }

        private void Update_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                string month = Convert.ToString(dataGridView1.SelectedRows[0].Cells[2].Value);
                int year = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[3].Value);
                int total = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[4].Value);
                int present = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[5].Value);
                string des = Convert.ToString(dataGridView1.SelectedRows[0].Cells[7].Value);

                Update_Form UF = new Update_Form(this, id, month, year, total, present, des);
                this.Hide();
                UF.Show();
            }
            else
            {
                MessageBox.Show("Please select a row");
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count >0)
            {
                DbConnection db = new DbConnection();
                int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                string month = Convert.ToString(dataGridView1.SelectedRows[0].Cells[2].Value);
                int year = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[3].Value);
                string des = Convert.ToString(dataGridView1.SelectedRows[0].Cells[7].Value);


                string query = "delete from Attendance where ID=" + id + " and Month='" + month + 
                    "' and Year=" + year + " and Designation='" + des + "'";

                DialogResult dialog = MessageBox.Show("Are you sure you want to permanently delete all records of this student?", "Warning", MessageBoxButtons.YesNo);
                if (dialog == DialogResult.Yes)
                {
                    try
                    {
                        db.Deletes(query);
                        MessageBox.Show("Successfully Deleted!");
                        int row = dataGridView1.CurrentCell.RowIndex;
                        dataGridView1.Rows.RemoveAt(row);

                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row.");
            }
        }

        private void Insert_Click(object sender, EventArgs e)
        {
            Insert_Form IF = new Insert_Form(this);
            this.Hide();
            IF.Show();
        }

        private void YearComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // if year else // if year month //else if month year 
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            string i;

            if (Desig == "Student")
            {

                if (GradeValue(GradeComboBox.Text) == "" && YearComboBox.Text == "")
                {
                    i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "'";
                }
                else if (GradeValue(GradeComboBox.Text) == "")
                {
                    i = "and Attendance.Year LIKE '" + YearComboBox.Text + "' AND Attendance.Month LIKE '" + MonthComboBox.Text + "'";
                }
                else if (YearComboBox.Text == "")
                {
                    i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "' AND Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "'";
                }
                else
                {
                    i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "' AND Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "' AND Attendance.Year LIKE '" + YearComboBox.Text + "'";
                }
                string q = "select Attendance.ID,Students.StudentName,Attendance.Month,Attendance.Year,Attendance.TotalDays," +
                    "Attendance.DaysPresent,Attendance.Percentage,Attendance.Designation from Attendance, Students where" +
                    " Attendance.ID = Students.ID and Attendance.Designation = 'Student' " + i;

                DbConnection d = new DbConnection();
                DataTable dt = d.Select(q);
                dataGridView1.DataSource = dt;

            }
            else
            {
                if (MonthComboBox.Text == "")
                {
                    i = "and Attendance.Year LIKE '" + YearComboBox.Text + "'";
                }
                else if (YearComboBox.Text == "")
                {
                    i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "'";
                }
                else
                {
                    i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "' AND Attendance.Year LIKE '" + YearComboBox.Text + "'";
                    //other = "SELECT TotalFees FROM TotalClassFees WHERE Grade LIKE '" + GradeValue(GradeComboBox.Text) + "' AND FeeMonth LIKE '" + MonthComboBox.Text + "' AND FeeYear LIKE '" + YearComboBox.Text + "'";
                }
                string q = "select Attendance.ID,Teachers.Name,Attendance.Month,Attendance.Year,Attendance.TotalDays," +
                    "Attendance.DaysPresent,Attendance.Percentage,Attendance.Designation from Attendance, Teachers where" +
                    " Attendance.ID = Teachers.ID and Attendance.Designation = 'Teacher' " + i;

                DbConnection d = new DbConnection();
                DataTable dt = d.Select(q);
                dataGridView1.DataSource = dt;
            }
        }

        private void MonthComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            string i;

            if (Desig=="Student")
            {
                if (GradeValue(GradeComboBox.Text) == "" && YearComboBox.Text == "")
                {
                    i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "'";
                }
                else if (GradeValue(GradeComboBox.Text) == "")
                {
                    i = "and Attendance.Year LIKE '" + YearComboBox.Text + "' AND Attendance.Month LIKE '" + MonthComboBox.Text + "'";
                }
                else if (YearComboBox.Text == "")
                {
                    i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "' AND Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "'";
                }
                else
                {
                    i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "' AND Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "' AND Attendance.Year LIKE '" + YearComboBox.Text + "'";
                }
                string q = "select Attendance.ID,Students.StudentName,Attendance.Month,Attendance.Year,Attendance.TotalDays," +
                    "Attendance.DaysPresent,Attendance.Percentage,Attendance.Designation from Attendance, Students where" +
                    " Attendance.ID = Students.ID and Attendance.Designation = 'Student' " + i;

                DbConnection d = new DbConnection();
                DataTable dt = d.Select(q);
                dataGridView1.DataSource = dt;

            }
            else
            {
                if (MonthComboBox.Text == "")
                {
                    i = "and Attendance.Year LIKE '" + YearComboBox.Text + "'";
                }
                else if (YearComboBox.Text == "")
                {
                    i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "'";
                }
                else
                {
                    i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "' AND Attendance.Year LIKE '" + YearComboBox.Text + "'";
                    //other = "SELECT TotalFees FROM TotalClassFees WHERE Grade LIKE '" + GradeValue(GradeComboBox.Text) + "' AND FeeMonth LIKE '" + MonthComboBox.Text + "' AND FeeYear LIKE '" + YearComboBox.Text + "'";
                }
                string q = "select Attendance.ID,Teachers.Name,Attendance.Month,Attendance.Year,Attendance.TotalDays," +
                    "Attendance.DaysPresent,Attendance.Percentage,Attendance.Designation from Attendance, Teachers where" +
                    " Attendance.ID = Teachers.ID and Attendance.Designation = 'Teacher' " + i;

                DbConnection d = new DbConnection();
                DataTable dt = d.Select(q);
                dataGridView1.DataSource = dt;
            }
        }

        private void GradeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Grade
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            string i;

            if (GradeValue(GradeComboBox.Text) == "" && YearComboBox.Text == "")
            {
                i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "'";
            }
            else if (GradeValue(GradeComboBox.Text) == "")
            {
                i = "and Attendance.Year LIKE '" + YearComboBox.Text + "' AND Attendance.Month LIKE '" + MonthComboBox.Text + "'";
            }
            else if (YearComboBox.Text == "")
            {
                i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "' AND Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "'";
            }
            else
            {
                i = "and Attendance.Month LIKE '" + MonthComboBox.Text + "' AND Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "' AND Attendance.Year LIKE '" + YearComboBox.Text + "'";
            }

            string q = "select Attendance.ID,Students.StudentName,Attendance.Month,Attendance.Year,Attendance.TotalDays," +
                "Attendance.DaysPresent,Attendance.Percentage,Attendance.Designation from Attendance, Students where" +
                " Attendance.ID = Students.ID and Attendance.Designation = 'Student' " +i;

            DbConnection d = new DbConnection();
            DataTable dt = d.Select(q);
            dataGridView1.DataSource = dt;
        }
    }
}
