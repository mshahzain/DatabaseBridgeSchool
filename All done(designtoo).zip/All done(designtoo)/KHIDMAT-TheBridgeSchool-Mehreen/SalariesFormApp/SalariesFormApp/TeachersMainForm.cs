﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TheBridgeSchool
{
    public partial class TeachersMainForm : Form
    {
        private string CurrentMode = "";
        private string savedOrnot = "No";

        private String TName = "";
        private String Class = "";
        private String GrNo = "";
        private String F_Name = "";
        private String DOJText = "";
        private String Contact = "";
        private String DOB = "";
        private String Qualf = "";
        private String Subject = "";
        private String Salary = "";

        private string connectionString = null;
        SqlConnection cnn;

        public TeachersMainForm()
        {
            InitializeComponent();
            DisableAll();
            IDTextBox.Enabled = false;
        }

        public TeachersMainForm(string Mode, string TeachID="")
        {
            InitializeComponent();
            CurrentMode = Mode;

            if(Mode == "ADD")
            {
                IDTextBox.Enabled = false;

                int id;
                button7.Text = "Save";
                EmptyAllTextBoxes();

                DbConnection db = new DbConnection();

                string query = "select top 1 ID from Teachers order by ID desc";

                id = db.IncrementID(query);

                if (id != -1)
                {
                    IDTextBox.Text = id.ToString();
                }
            }

            if(Mode == "EDIT")
            {
                DbConnection db = new DbConnection();
                connectionString = db.GetConnectionString();
                cnn = new SqlConnection(connectionString);
                string Sql = "Select * from Teachers where ID = '" + TeachID + "' ";
                cnn.Open();
                SqlCommand command = new SqlCommand(Sql, cnn);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    IDTextBox.Text = reader.GetValue(0).ToString();
                    GrNo = IDTextBox.Text;
                    NameTextBox.Text = reader.GetValue(1).ToString();
                    TName = NameTextBox.Text;
                    FNameTextBox.Text = reader.GetValue(2).ToString();
                    F_Name = FNameTextBox.Text;
                    ContactTextBox.Text = reader.GetValue(3).ToString();
                    Contact = ContactTextBox.Text;
                    if (reader.GetValue(6).ToString() == "")
                    {
                        dateTimePicker1.Value = Convert.ToDateTime("01/01/2012");
                    }
                    else { dateTimePicker1.Value = Convert.ToDateTime(reader.GetValue(6).ToString()); }
                    DOJText = dateTimePicker1.Value.ToLongDateString();
                    if(reader.GetValue(4).ToString() == "")
                    {
                        dateTimePickerBirthday.Value = Convert.ToDateTime("01/01/2019");
                    }
                    else { dateTimePickerBirthday.Value = Convert.ToDateTime(reader.GetValue(4).ToString()); }
                    DOB = dateTimePickerBirthday.Value.ToLongDateString();
                    QualTextBox.Text = reader.GetValue(5).ToString();
                    Qualf = QualTextBox.Text;
                    SubjectTextBox.Text = reader.GetValue(8).ToString();
                    Subject = SubjectTextBox.Text;
                    ClassTeachTextBox.Text = reader.GetValue(7).ToString();
                    Class = ClassTeachTextBox.Text;
                    SalaryTextBox.Text = reader.GetValue(9).ToString();
                    Salary = SalaryTextBox.Text;
                }

                cnn.Close();
            }
        }

        private void DisableAll()
        {
            SalaryTextBox.Enabled = false;
            IDTextBox.Enabled = false;
            FNameTextBox.Enabled = false;
            NameTextBox.Enabled = false;
            ContactTextBox.Enabled = false;
            dateTimePicker1.Enabled = false;
            dateTimePickerBirthday.Enabled = false;
            QualTextBox.Enabled = false;
            SubjectTextBox.Enabled = false;
            ClassTeachTextBox.Enabled = false;
           
            button7.Enabled = false;
        }
        private void EnableAll()
        {
            SalaryTextBox.Enabled = true;
            FNameTextBox.Enabled = true;
            NameTextBox.Enabled = true;
            ContactTextBox.Enabled = true;
            dateTimePicker1.Enabled = true;
            dateTimePickerBirthday.Enabled = true;
            QualTextBox.Enabled = true;
            SubjectTextBox.Enabled = true;
            ClassTeachTextBox.Enabled = true;
            
            button7.Enabled = true;
        }
        private void EmptyAllTextBoxes()
        {
            FNameTextBox.Text = "";
            IDTextBox.Text = "";
            NameTextBox.Text = "";
            ContactTextBox.Text = "";
            dateTimePicker1.Value = Convert.ToDateTime(" ");
            dateTimePickerBirthday.Value = Convert.ToDateTime(" ");
            QualTextBox.Text = "";
            SubjectTextBox.Text = "";
            ClassTeachTextBox.Text = "";
        }

        private bool CheckIfChanged()
        {
            if (GrNo == IDTextBox.Text)
            {
                if (TName == NameTextBox.Text)
                {
                    if (F_Name == FNameTextBox.Text)
                    {
                        if (Contact == ContactTextBox.Text)
                        {
                            if (DOJText == dateTimePicker1.Value.ToLongDateString())
                            {
                                if (Qualf == QualTextBox.Text)
                                {
                                    if (DOB == dateTimePickerBirthday.Value.ToLongDateString())
                                    {
                                        if (Subject == SubjectTextBox.Text)
                                        {
                                            if (Class == ClassTeachTextBox.Text)
                                            {
                                                return false;
                                            }
                                        }
                                    }
                                }

                            }
                        }

                    }
                }
            }
            return true;
        }
  
        private void Button7_Click(object sender, EventArgs e)
        {
            if (CurrentMode == "EDIT")
            {
                string updateQuery = "UPDATE Teachers Set Name ='" + NameTextBox.Text + "',FatherName ='" +
                    FNameTextBox.Text + "', Contact ='" + ContactTextBox.Text + "', DOB ='" +
                    dateTimePickerBirthday.Value.Date.ToString("yyyy/MM/dd HH:mm:ss") + "'," +
                    "DOJ ='" + dateTimePicker1.Value.Date.ToString("yyyy/MM/dd HH:mm:ss") + "' ," +
                    "Qualification ='" + QualTextBox.Text + "' ,  ClassTeacherOf='" +
                    ClassTeachTextBox.Text + "' ,Subject ='" + SubjectTextBox.Text + "' ," +
                    "Salary ='" + SalaryTextBox.Text + "' WHERE ID = '" + IDTextBox.Text + "'";

                DbConnection db = new DbConnection();
                try
                {
                    db.Update(updateQuery);
                    savedOrnot = "Yes";
                    MessageBox.Show("Successfully updated!");
                    this.Close();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if(CurrentMode == "ADD")
            {
                if (ClassTeachTextBox.Text != "" && NameTextBox.Text != "")
                {
                    DbConnection db = new DbConnection();

                    string addQuery = "Insert into Teachers (ID, Name, FatherName, Contact, DOB, Qualification,DOJ," +
                        "ClassTeacherOf, Subject, Salary) " +
                       "values('" + IDTextBox.Text + "', '" + NameTextBox.Text + "', '" + FNameTextBox.Text + "', '" + 
                       ContactTextBox.Text + "', '" + dateTimePickerBirthday.Value.Date.ToString("yyyy/MM/dd HH:mm:ss") + "', '"
                       + QualTextBox.Text + "', '" + dateTimePicker1.Value.Date.ToString("yyyy/MM/dd HH:mm:ss") 
                       + "', '" + ClassTeachTextBox.Text + "', '" + SubjectTextBox.Text + "', '" + SalaryTextBox.Text + "')";

                    try
                    {
                        db.Inserts(addQuery);
                        savedOrnot = "Yes";
                        MessageBox.Show("Successfully added!");
                        this.Close();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
                else
                {
                    MessageBox.Show("The Name and Class field can not be left empty");
                }
            }
        }
        private void Button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form4_Form_Closing(object sender, FormClosingEventArgs e)
        {
            if (savedOrnot == "No")
            {
                if (CheckIfChanged())
                {
                    DialogResult dialog = MessageBox.Show("Do you really want to close this, without saving?", "Warning", MessageBoxButtons.YesNo);
                    if (dialog == DialogResult.Yes)
                    {
                        e.Cancel = false;
                    }
                    else
                    {
                        e.Cancel = true;
                    }
                }
            }
        }

        private void SalaryTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int.Parse("0" + SalaryTextBox.Text);
            }
            catch
            {
                MessageBox.Show("Please, only add numbers in Salary\n Without spaces!");
            }
        }
    }
}

