﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TheBridgeSchool
{
    public partial class AllStudents : Form
    {
        public AllStudents()
        {
            InitializeComponent();
        }

        private string GradeValue(string gradeName)
        {
            string shortForm = "";
            if (gradeName == "Play Group")
            {
                shortForm = "PG";
            }
            else if (gradeName == "Lower Nursery")
            {
                shortForm = "LNY";
            }
            else if (gradeName == "Lower Nursery B")
            {
                shortForm = "LNB";
            }
            else if (gradeName == "1A")
            {
                shortForm = "1A";
            }
            else if (gradeName == "1B")
            {
                shortForm = "1B";
            }
            else if (gradeName == "2nd")
            {
                shortForm = "2A";
            }
            else if (gradeName == "3rd")
            {
                shortForm = "3A";
            }
            else if (gradeName == "4th")
            {
                shortForm = "4A";
            }
            else if (gradeName == "5th")
            {
                shortForm = "5A";
            }
            else if (gradeName == "6th")
            {
                shortForm = "6A";
            }
            else if (gradeName == "7th")
            {
                shortForm = "7A";
            }
            else if (gradeName == "8th")
            {
                shortForm = "8A";
            }
            return shortForm;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Reset form
            StudentsDataGridView.DataSource = null;
            StudentsDataGridView.Rows.Clear();

            string query1 = "SELECT ID, StudentName, FatherName, MotherName, ContactNo, DOB as 'Date Of Birth'," +
                " Attitude, Address  FROM Students WHERE Students.Class LIKE '"+ GradeValue(GradeComboBox.Text)+"'";

            DbConnection d = new DbConnection();
            DataTable dt = d.Select(query1);

            StudentsDataGridView.DataSource = dt;
        }

        private void NewStudentButton_Click(object sender, EventArgs e)
        {
            StudentsMainForm newForm = new StudentsMainForm("ADD");
            newForm.Show();
        }

        private void EditTeachBtton_Click(object sender, EventArgs e)
        {
            try
            {
                StudentsDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            }
            catch
            {
                MessageBox.Show("Please select a value!\n");
                return;
            }

            DbConnection d = new DbConnection();

            StudentsMainForm newForm = new StudentsMainForm("EDIT", StudentsDataGridView.SelectedRows[0].Cells[0].Value.ToString());

            newForm.Show();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            string StID = StudentsDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            DbConnection db = new DbConnection();
            string query = "DELETE FROM Students WHERE ID = '" + StID + "'";
            comboBox1_SelectedIndexChanged(sender, e);

            DialogResult dialog = MessageBox.Show("Are you sure you want to permanently delete all records of this student?", "Warning", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                try
                {
                    db.Deletes(query);
                    MessageBox.Show("Successfully deleted!");
                
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void label6_Click(object sender, EventArgs e)
        {
            comboBox1_SelectedIndexChanged(sender, e);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
