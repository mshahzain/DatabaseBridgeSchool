﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheBridgeSchool
{
    public partial class EditResults : Form
    {
        public EditResults()
        {
            InitializeComponent();
        }

        private void EditResults_Load(object sender, EventArgs e)
        {
            textBox1.Text = Records.Text1.ToString();
            textBox1.Enabled = false;
            textBox2.Text = Records.Text2;
            textBox2.Enabled = false;
            textBox3.Text = Records.Text3;
            textBox3.Enabled = false;
            textBox4.Text = Records.Text4;
            textBox4.Enabled = false;
            textBox5.Text = Records.Text5;
            textBox5.Enabled = false;
            textBox6.Text = Records.Text6;
            textBox7.Text = Records.Text7.ToString();
            textBox8.Text = Records.Text8.ToString();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            DbConnection d = new DbConnection();
            d.Update("UPDATE Results SET Date = '" + textBox6.Text + 
                "', TotalMarks = '" + textBox7.Text + "', MarksObtained = '" + textBox8.Text
                + "' WHERE ID LIKE '" + textBox1.Text + "' AND Description LIKE '" + textBox5.Text + "' AND Subject LIKE '" + textBox4.Text + "'");

            MessageBox.Show("Changes saved!");
        }

        private void TextBox8_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void TextBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter a valid value.");
            }
        }

        private void TextBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter a valid value.");
            }
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox7_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
