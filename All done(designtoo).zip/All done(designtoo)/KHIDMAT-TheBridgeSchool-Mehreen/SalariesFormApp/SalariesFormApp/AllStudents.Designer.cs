﻿namespace TheBridgeSchool
{
    partial class AllStudents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AllStudents));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label6 = new System.Windows.Forms.Label();
            this.DeleteTeachButton = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.EditTeachBtton = new System.Windows.Forms.Button();
            this.NewStudentButton = new System.Windows.Forms.Button();
            this.StudentsDataGridView = new System.Windows.Forms.DataGridView();
            this.GradeComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.StudentsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.Color.SeaShell;
            this.label6.Location = new System.Drawing.Point(848, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(148, 26);
            this.label6.TabIndex = 28;
            this.label6.Text = "🔄 REFRESH";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // DeleteTeachButton
            // 
            this.DeleteTeachButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DeleteTeachButton.BackgroundImage")));
            this.DeleteTeachButton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.DeleteTeachButton.Location = new System.Drawing.Point(626, 402);
            this.DeleteTeachButton.Name = "DeleteTeachButton";
            this.DeleteTeachButton.Size = new System.Drawing.Size(148, 27);
            this.DeleteTeachButton.TabIndex = 27;
            this.DeleteTeachButton.Text = "Delete Record";
            this.DeleteTeachButton.UseVisualStyleBackColor = true;
            this.DeleteTeachButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // button3
            // 
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button3.Location = new System.Drawing.Point(12, 402);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(120, 27);
            this.button3.TabIndex = 26;
            this.button3.Text = "Back";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // EditTeachBtton
            // 
            this.EditTeachBtton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("EditTeachBtton.BackgroundImage")));
            this.EditTeachBtton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.EditTeachBtton.Location = new System.Drawing.Point(780, 402);
            this.EditTeachBtton.Name = "EditTeachBtton";
            this.EditTeachBtton.Size = new System.Drawing.Size(148, 27);
            this.EditTeachBtton.TabIndex = 25;
            this.EditTeachBtton.Text = "Edit Record";
            this.EditTeachBtton.UseVisualStyleBackColor = true;
            this.EditTeachBtton.Click += new System.EventHandler(this.EditTeachBtton_Click);
            // 
            // NewStudentButton
            // 
            this.NewStudentButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("NewStudentButton.BackgroundImage")));
            this.NewStudentButton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.NewStudentButton.Location = new System.Drawing.Point(138, 402);
            this.NewStudentButton.Name = "NewStudentButton";
            this.NewStudentButton.Size = new System.Drawing.Size(148, 27);
            this.NewStudentButton.TabIndex = 24;
            this.NewStudentButton.Text = "Add New Student";
            this.NewStudentButton.UseVisualStyleBackColor = true;
            this.NewStudentButton.Click += new System.EventHandler(this.NewStudentButton_Click);
            // 
            // StudentsDataGridView
            // 
            this.StudentsDataGridView.AllowUserToAddRows = false;
            this.StudentsDataGridView.AllowUserToDeleteRows = false;
            this.StudentsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.StudentsDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.StudentsDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.StudentsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.StudentsDataGridView.Location = new System.Drawing.Point(12, 53);
            this.StudentsDataGridView.Name = "StudentsDataGridView";
            this.StudentsDataGridView.ReadOnly = true;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.StudentsDataGridView.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.StudentsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.StudentsDataGridView.Size = new System.Drawing.Size(916, 331);
            this.StudentsDataGridView.TabIndex = 23;
            // 
            // GradeComboBox
            // 
            this.GradeComboBox.FormattingEnabled = true;
            this.GradeComboBox.Items.AddRange(new object[] {
            "Play Group",
            "Lower Nursery",
            "Lower Nursery B",
            "1A",
            "1B",
            "2nd",
            "3rd",
            "4th",
            "5th",
            "6th",
            "7th",
            "8th"});
            this.GradeComboBox.Location = new System.Drawing.Point(379, 26);
            this.GradeComboBox.Name = "GradeComboBox";
            this.GradeComboBox.Size = new System.Drawing.Size(192, 34);
            this.GradeComboBox.TabIndex = 30;
            this.GradeComboBox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(276, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 29);
            this.label1.TabIndex = 29;
            this.label1.Text = "Select Grade:";
            // 
            // AllStudents
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(933, 450);
            this.Controls.Add(this.GradeComboBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.DeleteTeachButton);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.EditTeachBtton);
            this.Controls.Add(this.NewStudentButton);
            this.Controls.Add(this.StudentsDataGridView);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Maroon;
            this.Name = "AllStudents";
            this.Text = "AllStudents";
            ((System.ComponentModel.ISupportInitialize)(this.StudentsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button DeleteTeachButton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button EditTeachBtton;
        private System.Windows.Forms.Button NewStudentButton;
        private System.Windows.Forms.DataGridView StudentsDataGridView;
        private System.Windows.Forms.ComboBox GradeComboBox;
        private System.Windows.Forms.Label label1;
    }
}