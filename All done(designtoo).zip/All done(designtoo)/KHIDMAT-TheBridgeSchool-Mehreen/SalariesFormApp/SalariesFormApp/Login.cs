﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheBridgeSchool
{
    public partial class Login : Form
    {
        private String userName = "";
        private String password = "";
        public Login()
        {
            InitializeComponent();
            
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == userName)
            {
                if(textBox2.Text == password)
                {
                    HomepageForm newForm = new HomepageForm(this);
                    newForm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Incorrect Password! \nLogin Unsuccessful");
                }
            }
            else
            {
                MessageBox.Show("Incorrect Username! \nLogin Unsuccessful");
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("                               An EBMSᵀᴹ Production\n" +
                "This project has been developed for The Bridge School\n              by students of Habib University");
        }
    }
}
