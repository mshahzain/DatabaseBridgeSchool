﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheBridgeSchool
{
    public partial class Records : Form
    {
        public static int Text1;
        public static string Text2 = "";
        public static string Text3 = "";
        public static string Text4 = "";
        public static string Text5 = "";
        public static string Text6 = "";
        public static float Text7;
        public static float Text8;
        public Records()
        {
            InitializeComponent();
        }

        private void Results_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'khidmatDataSet.Results' table. You can move, or remove it, as needed.
            //this.resultsTableAdapter.Fill(khidmatDataSet.Results);

        }

        private string GradeValue(string gradeName)
        {
            string shortForm = "";
            if (gradeName == "Play Group")
            {
                shortForm = "PG";
            }
            else if (gradeName == "Lower Nursery")
            {
                shortForm = "LNY";
            }
            else if (gradeName == "Lower Nursery B")
            {
                shortForm = "LNB";
            }
            else if (gradeName == "1A")
            {
                shortForm = "1A";
            }
            else if (gradeName == "1B")
            {
                shortForm = "1B";
            }
            else if (gradeName == "2nd")
            {
                shortForm = "2A";
            }
            else if (gradeName == "3rd")
            {
                shortForm = "3A";
            }
            else if (gradeName == "4th")
            {
                shortForm = "4A";
            }
            else if (gradeName == "5th")
            {
                shortForm = "5A";
            }
            else if (gradeName == "6th")
            {
                shortForm = "6A";
            }
            else if (gradeName == "7th")
            {
                shortForm = "7A";
            }
            else if (gradeName == "8th")
            {
                shortForm = "8A";
            }
            return shortForm;
        }
        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void KhidmatDataSetBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SubComboBox.Items.Clear();
            AddDataToSubComboBox();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            string avg = "";
            string i;
            if (SubComboBox.Text != "" && ClassComboBox.Text != "")
            {
                i = "WHERE Results.Class LIKE '" + GradeValue(ClassComboBox.Text) + "' AND Results.Subject Like '" +
                SubComboBox.Text + "'";

            }
            else
            {
                i = "WHERE Results.Class LIKE '" + GradeValue(ClassComboBox.Text) + "'";
                avg = "EXEC class_result @grade ='" + GradeValue(ClassComboBox.Text) + "'";
            }

            string q = "SELECT Results.ID, StudentName as Name, Results.Class, Subject, Description, " +
                "Date, TotalMarks, MarksObtained " +
                "FROM Results RIGHT JOIN Students ON Results.ID = Students.ID " + i;
            DbConnection d = new DbConnection();
            DataTable dt = d.Select(q);
            dataGridView1.DataSource = dt;

            if (avg != "")
            {
                dt = d.Select(avg);
                for (int k = 0; k < dt.Rows.Count; k++)
                {
                    textBox1.Text = dt.Rows[k][0].ToString();
                    textBox1.Enabled = false;
                }
            }
        }

        private void AddDataToSubComboBox()
        {
            DbConnection db = new DbConnection();
            
            string Sql = "Select distinct Subject from Results where Class like '" + GradeValue(ClassComboBox.Text) + "' Order by Subject";

            db.conn.Open();
            db.cmd.CommandText = Sql;
            db.cmd.Connection = db.conn;
            SqlDataReader reader = db.cmd.ExecuteReader();
            while (reader.Read())
            {
                SubComboBox.Items.Add(reader.GetValue(0).ToString());
            }

            db.conn.Close();
        }


        private void populate()
        {
                Text1 = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                Text2 = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                Text3 = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                Text4 = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                Text5 = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                Text6 = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
                Text7 = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[6].Value);
                Text8 = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[7].Value);
        }

        private void Button2_Click(object sender, EventArgs e)  //Edit
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                populate();
                EditResults edit = new EditResults();
                edit.Show();
            }
            else
            {
                MessageBox.Show("Please select a row.");
            }
        }

        private void Button1_Click(object sender, EventArgs e)  //Add new
        {
            AddResult add = new AddResult();
            add.Show();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this record?", "Delete", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    string q = "DELETE FROM Results WHERE ID Like '" + Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value) +
                        "' AND Subject like '" + dataGridView1.SelectedRows[0].Cells[3].Value.ToString() + "' AND Description like '" + dataGridView1.SelectedRows[0].Cells[4].Value.ToString() + "'";
                    DbConnection d = new DbConnection();
                    DataTable dt = d.Select(q);
                    dataGridView1.DataSource = dt;
                    MessageBox.Show("Record Deleted! Select a category.");
                }
            }
            else
            {
                MessageBox.Show("Please select a row.");
            }
        }

        private void SubComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();

            string i;
            if (SubComboBox.Text != "" && ClassComboBox.Text != "")
            {
                i = "WHERE Results.Class LIKE '" + GradeValue(ClassComboBox.Text) + "' AND Results.Subject Like '" +
                SubComboBox.Text + "'";
            }
            else
            {
                SubComboBox.Items.Clear();
                i = "WHERE Results.CLass LIKE '" + GradeValue(ClassComboBox.Text) + "'";
            }

            string q = "SELECT Results.ID, StudentName as Name, Results.Class, Subject, Description, " +
                "Date, TotalMarks, MarksObtained " +
                "FROM Results RIGHT JOIN Students ON Results.ID = Students.ID " + i;
            DbConnection d = new DbConnection();
            DataTable dt = d.Select(q);
            dataGridView1.DataSource = dt;
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                populate();
               // ReportCard rc = new ReportCard();
               // rc.Show();
            }
            else
            {
                MessageBox.Show("Please select a row.");
            }

        }

        private void Label6_Click(object sender, EventArgs e)
        {
            //refresh form
            SubComboBox_SelectedIndexChanged(sender, e);

            ComboBox1_SelectedIndexChanged(sender, e);
        }
    }
}
