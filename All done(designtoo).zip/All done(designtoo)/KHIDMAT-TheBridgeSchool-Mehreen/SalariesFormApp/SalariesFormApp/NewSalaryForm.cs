﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheBridgeSchool
{
    public partial class NewSalaryForm : Form
    {
        int InitSalary = 0; 
        public NewSalaryForm()
        {
            InitializeComponent();
        }

        public NewSalaryForm(string month, string year)
        {
            InitializeComponent();
            MonthComboBox.Text = month;
            YearComboBox.Text = year;

            GoBackButton.Visible = false;
        }

        public NewSalaryForm(string TeachID,string TeachName, string month, string year, bool viewOnly)
        {
            InitializeComponent();

            NameComboBox.Enabled = false;
            MonthComboBox.Enabled = false;
            YearComboBox.Enabled = false;
            SaveButton.Visible = false;
            if (viewOnly)
            {
                GoBackButton.Visible = true;
                CancellingButton.Visible = false;

            InitialSalaryTextBox.Enabled = false;
            NetAmountTextBox.Enabled = false;
            PaidRadioButton.Enabled = false;
            UnpaidRadioButton.Enabled = false;

            AttendanceBonusTextBox.Enabled = false;
            LateSalaryTextBox.Enabled = false;
            AdditionsTextBox.Enabled = false;
            AbsencePenaltyTextBox.Enabled = false;
            AdvanceTakenTextBox.Enabled = false;
            DeadlinesNotMetTextBox.Enabled = false;
            GratuityTextBox.Enabled = false;
            DeductionsTextBox.Enabled = false;
            }

            string query = "SELECT * FROM TeacherSalaries WHERE TeacherID LIKE '"+TeachID+"' " +
                "AND MonthOfPayment LIKE '"+month+"' AND YearOfPayment LIKE '"+year+"'";
            DbConnection d = new DbConnection();
            DataTable dt = d.Select(query);

            NameComboBox.Text = TeachName;
            MonthComboBox.Text = dt.Rows[0][1].ToString();
            YearComboBox.Text = dt.Rows[0][2].ToString();
            InitialSalaryTextBox.Text = dt.Rows[0][3].ToString();
            AttendanceBonusTextBox.Text = dt.Rows[0][4].ToString();
            LateSalaryTextBox.Text = dt.Rows[0][5].ToString();
            AdditionsTextBox.Text = dt.Rows[0][6].ToString();
            AbsencePenaltyTextBox.Text = dt.Rows[0][7].ToString();
            AdvanceTakenTextBox.Text = dt.Rows[0][8].ToString();
            DeadlinesNotMetTextBox.Text = dt.Rows[0][9].ToString();
            GratuityTextBox.Text = dt.Rows[0][10].ToString();
            DeductionsTextBox.Text = dt.Rows[0][11].ToString();
            NetAmountTextBox.Text = dt.Rows[0][12].ToString();

            if(dt.Rows[0][13].ToString() == "Paid")
            {
                PaidRadioButton.Checked = true;
            }
            else if(dt.Rows[0][13].ToString() == "Not Paid")
            {
                UnpaidRadioButton.Checked = true;
            }

            if(!viewOnly)
            {
                UpdateButton.Visible = true;
                GoBackButton.Visible = false;
            }

        }

        private void NewSalaryForm_Load(object sender, EventArgs e)
        {
            DbConnection db = new DbConnection();

            string Sql = "SELECT Name FROM Teachers";

            db.conn.Open();
            db.cmd.CommandText = Sql;
            db.cmd.Connection = db.conn;
            SqlDataReader reader = db.cmd.ExecuteReader();
            while (reader.Read())
            {
                NameComboBox.Items.Add(reader.GetValue(0).ToString());
            }

            db.conn.Close();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            if (NameComboBox.Text == "" || MonthComboBox.Text == "" || YearComboBox.Text == "")
            {
                MessageBox.Show("Please, fill in the required fields.\n");
                return;
            }
            string PaymentStatus = "";
            if(PaidRadioButton.Checked)
            { PaymentStatus = "Paid"; }
            else
            { PaymentStatus = "Not Paid"; }

            int AttendanceBonus = 0, LateSalary = 0, AbsentPenalty = 0, Advance = 0, NotMeetDeadlines = 0,
                Gratuity = 0;

            //Check if all input types are correct
            try
            {
            AttendanceBonus = int.Parse("0" + AttendanceBonusTextBox.Text);
            LateSalary = int.Parse("0" + LateSalaryTextBox.Text);
            AbsentPenalty = int.Parse("0" + AbsencePenaltyTextBox.Text);
            Advance = int.Parse("0" + AdvanceTakenTextBox.Text);
            NotMeetDeadlines = int.Parse("0" + DeadlinesNotMetTextBox.Text);
            Gratuity = int.Parse("0" + GratuityTextBox.Text);
            InitSalary = int.Parse("0" + InitialSalaryTextBox.Text); 
            }
            catch
            {
                MessageBox.Show("Please enter only numbers in the fields.\nWithout any spaces!");
                return;
            }

            // Connect to Database and Insert new Entry
            DbConnection db = new DbConnection();
            DataTable dt = db.Select("SELECT ID FROM Teachers WHERE Name LIKE '" + NameComboBox.Text + "'");
            string TeacherID = dt.Rows[0][0].ToString();
            int TotalAddition = AttendanceBonus + LateSalary;
            int TotalDeduction = AbsentPenalty + Advance + NotMeetDeadlines + Gratuity;
            int ActualSalary =InitSalary + TotalAddition - TotalDeduction;

            NetAmountTextBox.Text = ActualSalary.ToString();

            string insertSalary = "INSERT INTO TeacherSalaries (TeacherID,MonthOfPayment,YearOfPayment," +
            "InitialSalary,AttendanceBonus,LateCompensation,AdditionTotal,AbsencePenalty,AdvanceTaken," +
            "DeadlinesPenalty,Gratuity,DeductionTotal,TotalSalary,PaymentStatus) "+
            "VALUES("+TeacherID+",'"+MonthComboBox.Text+"',"+YearComboBox.Text+","+ InitSalary+","+
            AttendanceBonus+","+ LateSalary +","+TotalAddition+","+AbsentPenalty+","+Advance+","+NotMeetDeadlines+
            ","+Gratuity+","+TotalDeduction+","+ActualSalary+",'"+PaymentStatus+"')";

            try
            {
                db.Inserts(insertSalary);
                MessageBox.Show("Succesfully saved!");
                this.Close();
            }
            catch (SqlException ex)
            {
                if (ex.Message.StartsWith("Violation of PRIMARY KEY constraint"))
                {
                    MessageBox.Show("You already have a record for this!\nPlease find and edit it instead.");
                }
                else { MessageBox.Show(ex.Message); } 
            }
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AttendanceBonusTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                AdditionsTextBox.Text = Convert.ToString(int.Parse("0"+AttendanceBonusTextBox.Text) 
                    + int.Parse("0"+LateSalaryTextBox.Text));

                NetAmountTextBox.Text = Convert.ToString(InitSalary +
      int.Parse("0" + AdditionsTextBox.Text) - int.Parse("0" + DeductionsTextBox.Text));
            }
            catch
            {
                MessageBox.Show("Please enter only numbers in all the fields.\nWithout any spaces!");
            }
        }

        private void AbsencePenaltyTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DeductionsTextBox.Text = Convert.ToString(int.Parse("0" + AbsencePenaltyTextBox.Text)
                + int.Parse("0" + AdvanceTakenTextBox.Text) + int.Parse("0" + DeadlinesNotMetTextBox.Text)
                + int.Parse("0" + GratuityTextBox.Text));

                NetAmountTextBox.Text = Convert.ToString(InitSalary +
                    int.Parse("0"+AdditionsTextBox.Text)-int.Parse("0" + DeductionsTextBox.Text));

            }
            catch
            {
                MessageBox.Show("Please enter only numbers in all the fields.\nWithout any spaces!");
            }
        }
        
        private void InitialSalaryTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                InitSalary = int.Parse("0"+InitialSalaryTextBox.Text);
                NetAmountTextBox.Text = Convert.ToString(InitSalary +
                int.Parse("0" + AdditionsTextBox.Text) - int.Parse("0" + DeductionsTextBox.Text));
            }
            catch
            {
                MessageBox.Show("Please enter only numbers in all the fields.\nWithout any spaces!");
            }
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            string PaymentStatus = "";
            if (PaidRadioButton.Checked)
            { PaymentStatus = "Paid"; }
            else
            { PaymentStatus = "Not Paid"; }

            int AttendanceBonus = 0, LateSalary = 0, AbsentPenalty = 0, Advance = 0, NotMeetDeadlines = 0,
                Gratuity = 0;
            //Check if all input types are correct
            try
            {
                AttendanceBonus = int.Parse("0" + AttendanceBonusTextBox.Text);
                LateSalary = int.Parse("0" + LateSalaryTextBox.Text);
                AbsentPenalty = int.Parse("0" + AbsencePenaltyTextBox.Text);
                Advance = int.Parse("0" + AdvanceTakenTextBox.Text);
                NotMeetDeadlines = int.Parse("0" + DeadlinesNotMetTextBox.Text);
                Gratuity = int.Parse("0" + GratuityTextBox.Text);
                InitSalary = int.Parse("0" + InitialSalaryTextBox.Text);
            }
            catch
            {
                MessageBox.Show("Please enter only numbers in the fields.\nWithout any spaces!");
                return;
            }

            // Connect to Database and Insert new Entry
            DbConnection db = new DbConnection();
            DataTable dt = db.Select("SELECT ID FROM Teachers WHERE Name LIKE '" + NameComboBox.Text + "'");
            string TeacherID = dt.Rows[0][0].ToString();
            int TotalAddition = AttendanceBonus + LateSalary;
            int TotalDeduction = AbsentPenalty + Advance + NotMeetDeadlines + Gratuity;
            int ActualSalary = InitSalary + TotalAddition - TotalDeduction;

            NetAmountTextBox.Text = ActualSalary.ToString();

            string updateEntry = "UPDATE TeacherSalaries SET InitialSalary = "+InitSalary+"," +
            "AttendanceBonus = "+AttendanceBonus+", LateCompensation = "+LateSalary+"," +
            "AdditionTotal = "+TotalAddition+", AbsencePenalty = "+AbsentPenalty+"," +
            "AdvanceTaken = "+Advance+", DeadlinesPenalty = "+NotMeetDeadlines+",Gratuity = "+Gratuity+"," +
            "DeductionTotal = "+TotalDeduction+",TotalSalary ="+ActualSalary+",PaymentStatus = '"+PaymentStatus+
            "' WHERE TeacherID LIKE '"+TeacherID+"' AND MonthOfPayment LIKE '"+MonthComboBox.Text+"'" +
            " AND YearOfPayment LIKE '"+YearComboBox.Text+"'";

            try
            {
                db.Update(updateEntry);
                MessageBox.Show("Succesfully updated!");
              
                this.Close();
            }
            catch (SqlException ex)
            {
                if (ex.Message.StartsWith("Violation of PRIMARY KEY constraint"))
                {
                    MessageBox.Show("You already have a record for this!\nPlease find and edit it instead.");
                }
                else { MessageBox.Show(ex.Message); }
            }
        }
    }
}
