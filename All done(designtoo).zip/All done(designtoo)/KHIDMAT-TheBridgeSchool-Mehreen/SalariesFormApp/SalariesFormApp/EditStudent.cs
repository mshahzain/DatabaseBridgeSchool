﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheBridgeSchool
{
    public partial class EditStudent : Form
    {
        public EditStudent()
        {
            InitializeComponent();
        }

        private void EditStudent_Load(object sender, EventArgs e)
        {
            textBox1.Text = FeeTable.SetValueForText2;
            textBox2.Text = FeeTable.SetValueForText3;
            textBox3.Text = FeeTable.SetValueForText4;
            textBox4.Text = FeeTable.SetValueForText5;
            comboBox1.Text = FeeTable.SetValueForText6;
            comboBox2.Text = FeeTable.SetValueForText7;
            textBox7.Text = FeeTable.SetValueForText1;
            textBox7.Enabled = false;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            if (FeeTable.SetValueForText8 == "TRUE")
            {
                checkBox1.Checked = true;
            }
            else
            {
                checkBox1.Checked = false;
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            DbConnection d = new DbConnection();
            string i;
            if (checkBox1.Checked == true)
            {
                i = "TRUE";
            }
            else
            {
                i = "";
            }
            d.Update("UPDATE StudentFees SET FeeAmount = '" + textBox3.Text + "', ReceiptNumber = '" + textBox4.Text +
                "', MonthOfFee = '" + comboBox1.Text + "', YearOfFee = '" + comboBox2.Text + "', Compensation = '" + i + "'"
                + " WHERE FeesID LIKE '" + textBox7.Text + "'");

            this.Hide();
            MessageBox.Show("Updated!");

            // Update Total Class Fees
            string getOldTotal = "SELECT ISNULL(TotalFees,'') as 'TotalFees' FROM TotalClassFees WHERE Grade LIKE '" + textBox2.Text +
            "' AND FeeMonth LIKE '" + comboBox1.Text + "' AND FeeYear LIKE '" + comboBox2.Text + "'";
            int oldTotal = 0;
            DataTable dt = d.Select(getOldTotal);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    oldTotal = Convert.ToInt32(dt.Rows[0][0].ToString());
                }
            }
            int Total;
            if (FeeTable.SetValueForText8 != "TRUE" && checkBox1.Checked == true)
            {
                Total = oldTotal - Convert.ToInt32(FeeTable.SetValueForText4);
            }
            else if(FeeTable.SetValueForText8 == "TRUE" && checkBox1.Checked == false)
            {
                Total = oldTotal + Convert.ToInt32(textBox3.Text);
            }
            else if(checkBox1.Checked == true && FeeTable.SetValueForText8 == "TRUE")
            {
                return;
            }
            else
            {
                oldTotal -= Convert.ToInt32(FeeTable.SetValueForText4);
                Total = oldTotal + Convert.ToInt32(textBox3.Text) ;
            }
            MessageBox.Show(oldTotal.ToString() + "\n" + getOldTotal);

            string updateTotal = "UPDATE TotalClassFees Set TotalFees = '" + Total + "' WHERE Grade LIKE '" + textBox2.Text +
            "' AND FeeMonth LIKE '" + comboBox1.Text + "' AND FeeYear LIKE '" + comboBox2.Text + "'";
            d.Update(updateTotal);
            MessageBox.Show(Total.ToString() + "\n" + updateTotal);
        }


        private void Button2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TextBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter a valid value.");
            }
        }

        private void TextBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter a valid value.");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
