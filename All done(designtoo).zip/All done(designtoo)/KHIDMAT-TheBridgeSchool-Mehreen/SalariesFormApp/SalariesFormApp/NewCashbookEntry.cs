﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TheBridgeSchool
{
    public partial class NewCashbookEntry : Form
    {
        private String TypeOfExpense;
        public NewCashbookEntry(String Sno)
        {
            InitializeComponent();
            if( Sno != "INSERT")
            {
                ExpenseTypeComboBox.Enabled = false;
            }
            MonthComboBox.Text = "January";
            DayComboBox.Text = "1";
            YearComboBox.Text = "2019";
            ExpenseTypeComboBox.Text = "Groceries";

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (ExpenseTypeComboBox.Text == "Groceries") { TypeOfExpense = "Grocery"; }
            else if (ExpenseTypeComboBox.Text == "Salary") { TypeOfExpense = "Salary"; }
            else if (ExpenseTypeComboBox.Text == "Stationary") { TypeOfExpense = "Staionary"; }
            else if (ExpenseTypeComboBox.Text == "Miscellaneous") { TypeOfExpense = " MiscellaneousExpenses"; }
            else if (ExpenseTypeComboBox.Text == "Received Cash") { TypeOfExpense = "MoneyReceived"; }
            int Amount=-1;
            
            try
            {
                Amount = int.Parse("0"+AmountTextBox.Text);
            }
            catch
            {
                MessageBox.Show("Please only add numbers in Amount");
            }
            if (Amount != -1)
            {
                string addQuery = "Insert into CashBookDaily (" + TypeOfExpense + ", Date, CurrentTrackingMonth,Year,Description, Recipient ) "
                + "values('" + Amount + "', '" + DayComboBox.Text + "', '" + MonthComboBox.Text + "', '" + YearComboBox.Text + "', '" + DescRichTextBox.Text + "', '"
                  + PaidTOTextBox.Text + "')";

                DbConnection d = new DbConnection();

                try
                {
                    d.Select(addQuery);
                    MessageBox.Show("Successfully added.");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
    }
}
