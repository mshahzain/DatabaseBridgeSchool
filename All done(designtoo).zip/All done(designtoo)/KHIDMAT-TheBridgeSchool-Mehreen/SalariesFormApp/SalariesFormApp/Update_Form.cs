﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TheBridgeSchool
{
    public partial class Update_Form : Form
    {
        int ID = 0;
        string designation = " ";
        string month_this = " ";
        int year_this = 0;
        int days_p = 0;
        int tot = 0;
        private AttendanceForm home;

        public Update_Form(AttendanceForm F, int id, string month, int year, int total, int present, string des)
        {
           
            InitializeComponent();
            home = F;
            ID = id;
            designation = des;
            month_this = month;
            year_this = year;
            days_p = present;
            tot = total;

            mon.Enabled = false;
            yr.Enabled = false;

            mon.Text = month;
            yr.Text = Convert.ToString(year);
            td.Text = Convert.ToString(total);
            dp.Text = Convert.ToString(present);
        }

        private void update_Click(object sender, EventArgs e)
        {
            // Calculate percentage
            tot = Convert.ToInt32(td.Text);
            days_p = Convert.ToInt32(dp.Text);

            float percent = 100 * ((float)days_p/(float)tot);

            string query = "update Attendance set TotalDays=" + tot + ", DaysPresent=" + days_p + ", Percentage=" + percent + 
                " where ID=" + ID + " and Designation='" + designation + "' and Year=" + year_this + "and Month = '" 
                + month_this + "'";
            DbConnection db = new DbConnection();

            try
            {
                db.Select(query);
                MessageBox.Show("Updated Successfully!");
                home.Refresh();
                home.Show();
                this.Close();
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
