﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheBridgeSchool
{
    
    public partial class HomepageForm : Form
    {
        private Login LG;

        public HomepageForm()
        {
            InitializeComponent();
        }

        public HomepageForm(Login lgForm)
        {
            InitializeComponent();
            LG = lgForm;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            AllStudents newform = new AllStudents();
            newform.Show();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            AllTeachers newform = new AllTeachers();
            newform.Show();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            CashbookForm newform = new CashbookForm();
            newform.Show();
        }

        private void HomepageForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            LG.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FeeRecordButton_Click(object sender, EventArgs e)
        {
            FeeTable newform = new FeeTable();
            newform.Show();
        }

        private void AttendanceButton_Click(object sender, EventArgs e)
        {
            
            AttendanceForm newform = new AttendanceForm();
            newform.Show();
        }

        private void ResultsButton_Click(object sender, EventArgs e)
        {
            Records newform = new Records();
            newform.Show();
        }

        private void SalariesButton_Click(object sender, EventArgs e)
        {
            SalariesForm newform = new SalariesForm();
            newform.Show();
        }
    }
}
