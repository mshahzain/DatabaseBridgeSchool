﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TheBridgeSchool
{
    public partial class Insert_Form : Form
    {
        int ID = 0;
        string Month = " ";
        int Year = 0;
        int TD = 0;
        int DP = 0;
        string Desig = " ";
        private AttendanceForm home;    

        public Insert_Form(AttendanceForm F)
        {
            InitializeComponent();
            home = F;
        }
        
        private void done_Click(object sender, EventArgs e)
        {
            // Insert all values.
            DbConnection db = new DbConnection();
            string conString = db.GetConnectionString();
            SqlConnection sq = new SqlConnection(conString);
            SqlCommand command = new SqlCommand();

            Month = MonthComboBox.Text;
            TD = Convert.ToInt32("0"+td.Text);
            DP = Convert.ToInt32("0"+dp.Text);
            Year = Convert.ToInt32("0"+YearComboBox.Text);

            if (Desig != " ")
            {
                if (Desig=="Teacher")
                {
                    DbConnection d = new DbConnection();
                    string query = "select ID from Teachers where Name = '" + comboBox2.Text + "'";
                    DataTable dt = d.Select(query);

                    ID = Convert.ToInt32(dt.Rows[0][0].ToString());
                    //MessageBox.Show(ID.ToString());
                }
                else
                {
                    // Student Query
                    DbConnection d = new DbConnection();
                    string query = "select ID from Students where StudentName='" + comboBox2.Text + "'";
                    DataTable dt = d.Select(query);

                    ID = Convert.ToInt32(dt.Rows[0][0].ToString());
                    //MessageBox.Show(ID.ToString());
                }
            }
            else
            {
                MessageBox.Show("Fill all required values!");
            }


            if ((ID != 0) && (Month != " ") && (Year != 0) && (TD != 0) && (Desig != " "))
            {
                float percent = 100 * ((float)DP / (float)TD);

                sq.Open();
                command.CommandText = "insert into Attendance(ID,Month,Year,TotalDays,DaysPresent,Percentage,Designation) values (@id,@m,@yr,@t,@d,@p,@des)";
                command.Connection = sq; //@id,@m,@yr,@t,@d,@p,@des
                command.Parameters.AddWithValue("@id", ID);
                command.Parameters.AddWithValue("@m", Month);
                command.Parameters.AddWithValue("@yr", Year);
                command.Parameters.AddWithValue("@t", TD);
                command.Parameters.AddWithValue("@d", DP);
                command.Parameters.AddWithValue("@p", percent);
                command.Parameters.AddWithValue("@des", Desig);

                command.ExecuteNonQuery();
                sq.Close();
                MessageBox.Show("Successfully Added!");
                home.Refresh();
                home.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Enter all values please.");
            }
        }
    
        private void Student_CheckedChanged(object sender, EventArgs e)
        {
            Desig = "Student";
            comboBox1.Enabled = true;
            DbConnection db = new DbConnection();
            string query = "select distinct Students.Class from Students";
            db.FillComboBox_2(comboBox1, query, "Class");
        }

        private void Teacher_CheckedChanged(object sender, EventArgs e)
        {
            Desig = "Teacher";
            comboBox1.Enabled = false;

            // Teacher's data displayed
            DbConnection db = new DbConnection();
            string query = "select Name from Teachers";
            db.FillComboBox_2(comboBox2, query, "Name");
        }

        private void year_TextChanged(object sender, EventArgs e)
        {
            int outputValue = 0;
            bool isNumber = false;
            isNumber = int.TryParse(YearComboBox.Text, out outputValue);
            if (!isNumber)
            {
                MessageBox.Show("Type numbers in the text boxes");
            }
        }

        private void td_TextChanged(object sender, EventArgs e)
        {
            int outputValue = 0;
            bool isNumber = false;
            isNumber = int.TryParse(td.Text, out outputValue);
            if (!isNumber)
            {
                MessageBox.Show("Type numbers in the text boxes");
            }
        }

        private void dp_TextChanged(object sender, EventArgs e)
        {
            int outputValue = 0;
            bool isNumber = false;
            isNumber = int.TryParse(dp.Text, out outputValue);
            if (!isNumber)
            {
                MessageBox.Show("Type numbers in the text boxes");
            }
        }
        
        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // Students' data displayed
            DbConnection db = new DbConnection();
            string query = "select Students.StudentName from Students where Students.Class = '" + comboBox1.Text + "'";
            comboBox2.Items.Clear();
            comboBox2.Text = "";
            db.FillComboBox_2(comboBox2, query, "StudentName");
        }

        private void MonthComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
