﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TheBridgeSchool
{
    public partial class FeeTable : Form
    {
        public static string SetValueForText1 = "";
        public static string SetValueForText2 = "";
        public static string SetValueForText3 = "";
        public static string SetValueForText4 = "";
        public static string SetValueForText5 = "";
        public static string SetValueForText6 = "";
        public static string SetValueForText7 = "";
        public static string SetValueForText8 = "";
        public FeeTable()
        {
            InitializeComponent();
        }

        private void FeeTable_Load(object sender, EventArgs e)
        {

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private string GradeValue(string gradeName, bool flag=false)
        {
            string shortForm = "";
            if (gradeName == "Play Group")
            {
                shortForm = "PG";
            }
            else if (gradeName == "Lower Nursery")
            {
                if (flag) { shortForm = "LNY"; }
                else { shortForm = "LNY' OR Students.Class LIKE 'LNB"; }
            }
            else if (gradeName == "Upper Nursery")
            {
                shortForm = "UN";
            }
            else if (gradeName == "1A")
            {
                shortForm = "1A";
            }
            else if (gradeName == "1B")
            {
                shortForm = "1B";
            }
            else if (gradeName == "2nd")
            {
                shortForm = "2A";
            }
            else if (gradeName == "3rd")
            {
                shortForm = "3A";
            }
            else if (gradeName == "4th")
            {
                shortForm = "4A";
            }
            else if (gradeName == "5th")
            {
                shortForm = "5A";
            }
            else if (gradeName == "6th")
            {
                shortForm = "6A";
            }
            else if (gradeName == "7th")
            {
                shortForm = "7A";
            }
            else if (gradeName == "8th")
            {
                shortForm = "8A";
            }
            return shortForm;
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            string i;
            string other = "";
            textBox1.Text = "";
            if (GradeValue(GradeComboBox.Text) == "" && YearComboBox.Text == "")
            {
                i = "WHERE StudentFees.MonthOfFee LIKE '" + MonthComboBox.Text + "'";
            }
            else if (GradeValue(GradeComboBox.Text) == "")
            {
                i = "WHERE StudentFees.YearOfFee LIKE '" + YearComboBox.Text + "' AND StudentFees.MonthOfFee LIKE '" + MonthComboBox.Text + "'";
            }
            else if (YearComboBox.Text == "")
            {
                i = "WHERE StudentFees.MonthOfFee LIKE '" + MonthComboBox.Text + "' AND (Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "')";
            }
            else
            {
                i = "WHERE StudentFees.MonthOfFee LIKE '" + MonthComboBox.Text + "' AND (Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "') AND StudentFees.YearOfFee LIKE '" + YearComboBox.Text + "'";
                other = "SELECT TotalFees FROM TotalClassFees WHERE Grade LIKE '" + GradeValue(GradeComboBox.Text, true) + "' AND FeeMonth LIKE '" + MonthComboBox.Text + "' AND FeeYear LIKE '" + YearComboBox.Text + "'";
            }

            string q = "SELECT FeesID, StudentName, Class, FeeAmount, ReceiptNumber, " +
                "MonthOfFee, YearOfFee, Compensation " +
                "FROM StudentFees RIGHT JOIN Students ON StudentFees.StudentID = Students.ID  " + i;
            try
            {
                DbConnection d = new DbConnection();
                DataTable dt = d.Select(q);
                dataGridView1.DataSource = dt;
                if (other != "")
                {
                    dt = d.Select(other);
                    for (int k = 0; k < dt.Rows.Count; k++)
                    {
                        textBox1.Text = dt.Rows[k][0].ToString();
                    }
                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            string i;
            string other = "";
            textBox1.Text = "";
            if (GradeValue(GradeComboBox.Text) == "" && MonthComboBox.Text == "")
            {
                i = "WHERE StudentFees.YearOfFee LIKE '" + YearComboBox.Text + "'";
            }
            else if (GradeValue(GradeComboBox.Text) == "")
            {
                i = "WHERE StudentFees.YearOfFee LIKE '" + YearComboBox.Text + "' AND StudentFees.MonthOfFee LIKE '" + MonthComboBox.Text + "'";
            }
            else if (MonthComboBox.Text == "")
            {
                i = "WHERE StudentFees.YearOfFee LIKE '" + YearComboBox.Text + "' AND (Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "')";
            }
            else
            {
                i = "WHERE StudentFees.MonthOfFee LIKE '" + MonthComboBox.Text + "' AND (Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "') AND StudentFees.YearOfFee LIKE '" + YearComboBox.Text + "'";
                other = "SELECT TotalFees FROM TotalClassFees WHERE Grade LIKE '" + GradeValue(GradeComboBox.Text, true) + "' AND FeeMonth LIKE '" + MonthComboBox.Text + "' AND FeeYear LIKE '" + YearComboBox.Text + "'";
            }
            string q = "SELECT FeesID, StudentName, Class, FeeAmount, ReceiptNumber, " +
                "MonthOfFee, YearOfFee, Compensation " +
                "FROM StudentFees RIGHT JOIN Students ON StudentFees.StudentID = Students.ID  " + i;

            DbConnection d = new DbConnection();
            DataTable dt = d.Select(q);
            dataGridView1.DataSource = dt;
            if (other != "")
            {
                dt = d.Select(other);
                for (int k = 0; k < dt.Rows.Count; k++)
                {
                    textBox1.Text = dt.Rows[k][0].ToString();
                }
            }

        }

        private void ComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            string i;
            string other = "";
            textBox1.Text = "";
            if (YearComboBox.Text == "" && MonthComboBox.Text == "")
            {
                i = "WHERE (Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "')";
            }
            else if (MonthComboBox.Text == "")
            {
                i = "WHERE StudentFees.YearOfFee LIKE '" + YearComboBox.Text + "' AND (Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "')";
            }
            else if (YearComboBox.Text == "")
            {
                i = "WHERE StudentFees.MonthOfFee LIKE '" + MonthComboBox.Text + "' AND (Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "')";
            }
            else
            {
                i = "WHERE StudentFees.MonthOfFee LIKE '" + MonthComboBox.Text + "' AND StudentFees.YearOfFee LIKE '" + YearComboBox.Text + "' AND (Students.Class LIKE '" + GradeValue(GradeComboBox.Text) + "')";
                other = "SELECT TotalFees FROM TotalClassFees WHERE Grade LIKE '" + GradeValue(GradeComboBox.Text,true) + "' AND FeeMonth LIKE '" + MonthComboBox.Text + "' AND FeeYear LIKE '" + YearComboBox.Text + "'";
            }
            string q = "SELECT StudentFees.FeesID, Students.StudentName, Students.Class, StudentFees.FeeAmount, StudentFees.ReceiptNumber,"
                + " StudentFees.MonthOfFee, StudentFees.YearOfFee, StudentFees.Compensation " +
                "FROM StudentFees RIGHT JOIN Students ON StudentFees.StudentID = Students.ID  " + i;

            try
            {
                DbConnection d = new DbConnection();
                DataTable dt = d.Select(q);
                dataGridView1.DataSource = dt;
                if (other != "")
                {
                    dt = d.Select(other);
                    for (int k = 0; k < dt.Rows.Count; k++)
                    {
                        textBox1.Text = dt.Rows[k][0].ToString();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(q+"\n"+ex.Message);
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                SetValueForText1 = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                SetValueForText2 = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                SetValueForText3 = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                SetValueForText4 = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                SetValueForText5 = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                SetValueForText6 = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
                SetValueForText7 = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
                SetValueForText8 = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
                EditStudent editStudent = new EditStudent();
                editStudent.Show();
            }
            else
            {
                MessageBox.Show("Please select a row.");
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            AddNewStdFee add = new AddNewStdFee();
            add.Show();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this record?", "Delete", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    string q = "DELETE FROM StudentFees WHERE FeesID Like '" + dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + "'";
                    DbConnection d = new DbConnection();
                    d.Deletes(q);
                    MessageBox.Show("Fee Record Deleted! Select a category.");

                    // Update Total Class Fees
                    string getOldTotal = "SELECT ISNULL(TotalFees,'') as 'TotalFees' FROM TotalClassFees WHERE Grade LIKE '" + dataGridView1.SelectedRows[0].Cells[2].Value.ToString() +
                    "' AND FeeMonth LIKE '" + dataGridView1.SelectedRows[0].Cells[5].Value.ToString() + "' AND FeeYear LIKE '" + dataGridView1.SelectedRows[0].Cells[6].Value.ToString() + "'";
                    int oldTotal = 0;
                    DataTable dt = d.Select(getOldTotal);
                    if (dt != null)
                    {
                        if (dt.Rows.Count > 0)
                        {
                            oldTotal = Convert.ToInt32(dt.Rows[0][0].ToString());
                        }
                    }
                    int Total = oldTotal - Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[3].Value.ToString());
                    if (Total < 0) { Total = 0; }
                    string updateTotal = "UPDATE TotalClassFees Set TotalFees = '" + Total + "' WHERE Grade LIKE '" + dataGridView1.SelectedRows[0].Cells[2].Value.ToString() +
                    "' AND FeeMonth LIKE '" + dataGridView1.SelectedRows[0].Cells[5].Value.ToString() + "' AND FeeYear LIKE '" + dataGridView1.SelectedRows[0].Cells[6].Value.ToString() + "'";
                    d.Update(updateTotal);
                }
            }
            else
            {
                MessageBox.Show("Please select a row.");
            }

        }

        private void label6_Click(object sender, EventArgs e)
        {
            ComboBox1_SelectedIndexChanged(sender, e);
            ComboBox2_SelectedIndexChanged(sender, e);
            ComboBox3_SelectedIndexChanged(sender, e);
        }
    }
}
