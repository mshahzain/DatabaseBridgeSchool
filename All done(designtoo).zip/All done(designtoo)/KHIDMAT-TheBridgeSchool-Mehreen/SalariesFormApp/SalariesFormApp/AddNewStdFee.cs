﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheBridgeSchool
{
    public partial class AddNewStdFee : Form
    {
        DataTable Students;
        public AddNewStdFee()
        {
            InitializeComponent();
        }

        private string GradeValue(string gradeName)
        {
            string shortForm = "";
            if (gradeName == "Play Group")
            {
                shortForm = "PG";
            }
            else if (gradeName == "Lower Nursery")
            {
                shortForm = "LNY";
            }
            else if (gradeName == "Upper Nursery")
            {
                shortForm = "UN";
            }
            else if (gradeName == "1A")
            {
                shortForm = "1A";
            }
            else if (gradeName == "1B")
            {
                shortForm = "1B";
            }
            else if (gradeName == "2nd")
            {
                shortForm = "2A";
            }
            else if (gradeName == "3rd")
            {
                shortForm = "3A";
            }
            else if (gradeName == "4th")
            {
                shortForm = "4A";
            }
            else if (gradeName == "5th")
            {
                shortForm = "5A";
            }
            else if (gradeName == "6th")
            {
                shortForm = "6A";
            }
            else if (gradeName == "7th")
            {
                shortForm = "7A";
            }
            else if (gradeName == "8th")
            {
                shortForm = "8A";
            }
            return shortForm;
        }

        private void AddDataToComboBox()
        {
            DbConnection db = new DbConnection();

            string Sql = "Select * from Students where Class like '" + GradeValue(ClassComboBox.Text) + "' Order by StudentName";

            DataTable dt = db.Select(Sql);
            Students = dt;

            foreach (DataRow row in dt.Rows)
            {
                NameComboBox.Items.Add(row["StudentName"].ToString());
            }
            /*
            db.conn.Open();
            db.cmd.CommandText = Sql;
            db.cmd.Connection = db.conn;
            SqlDataReader reader = db.cmd.ExecuteReader();
            while (reader.Read())
            {
                NameComboBox.Items.Add(reader.GetValue(0).ToString());
            }
            //db.cmd.ExecuteNonQuery();
            db.conn.Close();
            */
        }

        private void AddNewStdFee_Load(object sender, EventArgs e)
        {
            
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ClassComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            NameComboBox.Items.Clear();
            AddDataToComboBox();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if(textBox3.Text == "" || textBox4.Text == "" || comboBox1.Text == "" 
                || comboBox2.Text == "" || ClassComboBox.Text == "" || NameComboBox.Text == "")
            {
                MessageBox.Show("All fields are required");
                return;
            }
            DbConnection d = new DbConnection();
            string i;
            string studentID = "";
            if (checkBox1.Checked == true)
            {
                i = "TRUE";
            }
            else
            {
                i = "";
            }
            //string studentIDQUERY = "SELECT ID FROM Students WHERE Students.StudentName LIKE '" + NameComboBox.Text + "'";
            //DataTable dt2 = d.Select(studentIDQUERY);
            //string studentID = dt2.Rows[0][0].ToString();
            foreach (DataRow row in Students.Rows)
            {
                if(row["StudentName"].ToString() == NameComboBox.Text)
                {
                    studentID = row["ID"].ToString();

                }
            }
            string query = "INSERT INTO StudentFees (StudentID, FeeAmount,ReceiptNumber,MonthOfFee,YearOfFee,Compensation) " +
                "VALUES(" + studentID + ", " + textBox3.Text + ", " + textBox4.Text + ", '" + comboBox1.Text + "', " +
                comboBox2.Text + ", '" + i + "')";
           
            try
            {
                d.Inserts(query);
                MessageBox.Show("Successfully Saved!");
                // Update Total Class Fees
                string getOldTotal = "SELECT ISNULL(TotalFees,'') as 'TotalFees' FROM TotalClassFees WHERE Grade LIKE '" + GradeValue(ClassComboBox.Text) +
                "' AND FeeMonth LIKE '" + comboBox1.Text + "' AND FeeYear LIKE '" + comboBox2.Text + "'";
                int oldTotal = 0;
                DataTable dt = d.Select(getOldTotal);
                if (dt != null)
                {
                    if(dt.Rows.Count >0)
                    {
 //                       MessageBox.Show(dt.Rows[0][0].ToString());
                        oldTotal = Convert.ToInt32(dt.Rows[0][0].ToString());
                    }
                    else
                    {
                        //MessageBox.Show("Inserted new");
                        d.Inserts("INSERT INTO TotalClassFees (Grade, FeeMonth, FeeYear) VALUES ('" + GradeValue(ClassComboBox.Text)
                            + "', '" + comboBox1.Text + "', '" + comboBox2.Text + "')");
                        getOldTotal = "SELECT ISNULL(TotalFees,'') as 'TotalFees' FROM TotalClassFees WHERE Grade LIKE '" + GradeValue(ClassComboBox.Text) +
                "' AND FeeMonth LIKE '" + comboBox1.Text + "' AND FeeYear LIKE '" + comboBox2.Text + "'";
                        dt = d.Select(getOldTotal);
                        oldTotal = Convert.ToInt32(dt.Rows[0][0].ToString());
                    }
                }
                
                MessageBox.Show(oldTotal.ToString() + "\n" + getOldTotal);
                int Total = Convert.ToInt32(textBox3.Text) + oldTotal;
                string updateTotal = "UPDATE TotalClassFees Set TotalFees = '"+Total+"' WHERE Grade LIKE '" + GradeValue(ClassComboBox.Text) +
                "' AND FeeMonth LIKE '" + comboBox1.Text + "' AND FeeYear LIKE '" + comboBox2.Text + "'";
                d.Update(updateTotal);
                MessageBox.Show(Total.ToString() + "\n" + updateTotal);
                
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message + "\n" +query);
            }

        }

        private void NameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void TextBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter a valid value.");
            }
        }

        private void TextBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter a valid value.");
            }
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }
    }
}
