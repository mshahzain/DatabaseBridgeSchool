﻿namespace TheBridgeSchool
{
    partial class HomepageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomepageForm));
            this.StudentInfoButton = new System.Windows.Forms.Button();
            this.TeacherInfoButton = new System.Windows.Forms.Button();
            this.CashbookButton = new System.Windows.Forms.Button();
            this.FeeRecordButton = new System.Windows.Forms.Button();
            this.AttendanceButton = new System.Windows.Forms.Button();
            this.ResultsButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SalariesButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // StudentInfoButton
            // 
            this.StudentInfoButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("StudentInfoButton.BackgroundImage")));
            this.StudentInfoButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.StudentInfoButton.Location = new System.Drawing.Point(231, 13);
            this.StudentInfoButton.Margin = new System.Windows.Forms.Padding(2);
            this.StudentInfoButton.Name = "StudentInfoButton";
            this.StudentInfoButton.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StudentInfoButton.Size = new System.Drawing.Size(160, 37);
            this.StudentInfoButton.TabIndex = 0;
            this.StudentInfoButton.Text = "Student Information";
            this.StudentInfoButton.UseVisualStyleBackColor = true;
            this.StudentInfoButton.Click += new System.EventHandler(this.Button1_Click);
            // 
            // TeacherInfoButton
            // 
            this.TeacherInfoButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TeacherInfoButton.BackgroundImage")));
            this.TeacherInfoButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.TeacherInfoButton.Location = new System.Drawing.Point(231, 54);
            this.TeacherInfoButton.Margin = new System.Windows.Forms.Padding(2);
            this.TeacherInfoButton.Name = "TeacherInfoButton";
            this.TeacherInfoButton.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TeacherInfoButton.Size = new System.Drawing.Size(160, 37);
            this.TeacherInfoButton.TabIndex = 2;
            this.TeacherInfoButton.Text = "Teacher";
            this.TeacherInfoButton.UseVisualStyleBackColor = true;
            this.TeacherInfoButton.Click += new System.EventHandler(this.Button3_Click);
            // 
            // CashbookButton
            // 
            this.CashbookButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CashbookButton.BackgroundImage")));
            this.CashbookButton.Location = new System.Drawing.Point(231, 260);
            this.CashbookButton.Margin = new System.Windows.Forms.Padding(2);
            this.CashbookButton.Name = "CashbookButton";
            this.CashbookButton.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CashbookButton.Size = new System.Drawing.Size(160, 37);
            this.CashbookButton.TabIndex = 3;
            this.CashbookButton.Text = "Cashbook";
            this.CashbookButton.UseVisualStyleBackColor = true;
            this.CashbookButton.Click += new System.EventHandler(this.Button2_Click);
            // 
            // FeeRecordButton
            // 
            this.FeeRecordButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("FeeRecordButton.BackgroundImage")));
            this.FeeRecordButton.Location = new System.Drawing.Point(231, 96);
            this.FeeRecordButton.Name = "FeeRecordButton";
            this.FeeRecordButton.Size = new System.Drawing.Size(160, 37);
            this.FeeRecordButton.TabIndex = 4;
            this.FeeRecordButton.Text = "Fee Records";
            this.FeeRecordButton.UseVisualStyleBackColor = true;
            this.FeeRecordButton.Click += new System.EventHandler(this.FeeRecordButton_Click);
            // 
            // AttendanceButton
            // 
            this.AttendanceButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("AttendanceButton.BackgroundImage")));
            this.AttendanceButton.Location = new System.Drawing.Point(231, 139);
            this.AttendanceButton.Name = "AttendanceButton";
            this.AttendanceButton.Size = new System.Drawing.Size(160, 34);
            this.AttendanceButton.TabIndex = 5;
            this.AttendanceButton.Text = "Attendance";
            this.AttendanceButton.UseVisualStyleBackColor = true;
            this.AttendanceButton.Click += new System.EventHandler(this.AttendanceButton_Click);
            // 
            // ResultsButton
            // 
            this.ResultsButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ResultsButton.BackgroundImage")));
            this.ResultsButton.Location = new System.Drawing.Point(231, 179);
            this.ResultsButton.Name = "ResultsButton";
            this.ResultsButton.Size = new System.Drawing.Size(160, 37);
            this.ResultsButton.TabIndex = 6;
            this.ResultsButton.Text = "Results";
            this.ResultsButton.UseVisualStyleBackColor = true;
            this.ResultsButton.Click += new System.EventHandler(this.ResultsButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(36, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(122, 106);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Verdana", 7.875F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(12, 267);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "Logout ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // SalariesButton
            // 
            this.SalariesButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SalariesButton.BackgroundImage")));
            this.SalariesButton.Location = new System.Drawing.Point(231, 221);
            this.SalariesButton.Name = "SalariesButton";
            this.SalariesButton.Size = new System.Drawing.Size(160, 34);
            this.SalariesButton.TabIndex = 9;
            this.SalariesButton.Text = "Salaries";
            this.SalariesButton.UseVisualStyleBackColor = true;
            this.SalariesButton.Click += new System.EventHandler(this.SalariesButton_Click);
            // 
            // HomepageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(409, 309);
            this.Controls.Add(this.SalariesButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ResultsButton);
            this.Controls.Add(this.AttendanceButton);
            this.Controls.Add(this.FeeRecordButton);
            this.Controls.Add(this.CashbookButton);
            this.Controls.Add(this.TeacherInfoButton);
            this.Controls.Add(this.StudentInfoButton);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Maroon;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "HomepageForm";
            this.Text = "Home";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.HomepageForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button StudentInfoButton;
        private System.Windows.Forms.Button TeacherInfoButton;
        private System.Windows.Forms.Button CashbookButton;
        private System.Windows.Forms.Button FeeRecordButton;
        private System.Windows.Forms.Button AttendanceButton;
        private System.Windows.Forms.Button ResultsButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button SalariesButton;
    }
}