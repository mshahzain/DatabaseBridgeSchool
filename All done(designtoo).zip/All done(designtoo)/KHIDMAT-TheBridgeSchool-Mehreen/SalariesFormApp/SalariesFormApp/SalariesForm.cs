﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheBridgeSchool
{
    public partial class SalariesForm : Form
    {
        public SalariesForm()
        {
            InitializeComponent();
        }

        private void YearComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Reset form
            SalariesDataGridView.DataSource = null;
            SalariesDataGridView.Rows.Clear();
            AdditionalSalaryDataGridView.DataSource = null;
            AdditionalSalaryDataGridView.Rows.Clear();
            textBox1.Clear();
            string totalSalary = "";
            string query1 = "SELECT Teachers.Name as 'Name', ISNULL(InitialSalary, '') as 'Initial Salary'," +
            " MonthOfPayment as 'Month', YearOfPayment as 'Year',ISNULL(TotalSalary, '') as 'Net Amount'," +
            " ISNULL(PaymentStatus, '') as 'Payment Status' " +
            "FROM TeacherSalaries RIGHT JOIN Teachers ON TeacherSalaries.TeacherID = Teachers.ID " +
            "WHERE TeacherSalaries.YearOfPayment LIKE '" + YearComboBox.Text + "'";
            string query2 = "SELECT Teachers.Name as 'Name', MonthOfPayment as 'Month', YearOfPayment as 'Year', " +
            "ISNULL(AttendanceBonus, '') as 'Attendance Bonus', ISNULL(LateCompensation, '') as 'Late Salary', " +
            "ISNULL(AdditionTotal, '') as 'Total Addition', ISNULL(AbsencePenalty, '') as 'Absent Penalty'," +
            "ISNULL(AdvanceTaken, '') as 'Advance Deducted', ISNULL(DeadlinesPenalty, '') as 'Deadlines Not Met', ISNULL(Gratuity, '') as 'Gratuity', " +
            "ISNULL(DeductionTotal, '') as 'Total Deduction' " +
            "FROM TeacherSalaries RIGHT JOIN Teachers ON TeacherSalaries.TeacherID = Teachers.ID " +
            "WHERE TeacherSalaries.YearOfPayment LIKE '" + YearComboBox.Text + "'"; 

            if (MonthComboBox.Text != "")
            {
                query1 += " AND TeacherSalaries.MonthOfPayment LIKE '" + MonthComboBox.Text + "'";
                query2 += " AND TeacherSalaries.MonthOfPayment LIKE '" + MonthComboBox.Text + "'";
                totalSalary = "SELECT TotalSalaries, TotalInitialSalaries FROM MonthlySalaries WHERE" +
                    " MonthOfPayment LIKE '"+ MonthComboBox.Text + "' AND YearOfPayment LIKE '"+YearComboBox.Text+"'";
            }

            DbConnection d = new DbConnection();
            DataTable dt = d.Select(query1);
            DataTable dt2 = d.Select(query2);

            SalariesDataGridView.DataSource = dt;
            AdditionalSalaryDataGridView.DataSource = dt2;
            
            if (totalSalary != "")
            {
                dt = d.Select(totalSalary);
                for (int k = 0; k < dt.Rows.Count; k++)
                {
                    textBox1.Text = dt.Rows[k][0].ToString();
                }
            }

            label4.Visible = true;
            label5.Visible = true;
        }

        private void MonthComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Reset form
            SalariesDataGridView.DataSource = null;
            SalariesDataGridView.Rows.Clear();
            textBox1.Clear();
            string totalSalary = "";
            string query1 = "SELECT Teachers.Name as 'Name', ISNULL(InitialSalary, '') as 'Initial Salary'," +
            " MonthOfPayment as 'Month', YearOfPayment as 'Year',ISNULL(TotalSalary, '') as 'Net Amount'," +
            " ISNULL(PaymentStatus, '') as 'Payment Status' " +
            "FROM TeacherSalaries RIGHT JOIN Teachers ON TeacherSalaries.TeacherID = Teachers.ID " +
            "WHERE TeacherSalaries.MonthOfPayment LIKE '" + MonthComboBox.Text + "'";
            string query2 = "SELECT Teachers.Name as 'Name', MonthOfPayment as 'Month', YearOfPayment as 'Year', " +
            "ISNULL(AttendanceBonus, '') as 'Attendance Bonus', ISNULL(LateCompensation, '') as 'Late Salary', " +
            "ISNULL(AdditionTotal, '') as 'Total Addition', ISNULL(AbsencePenalty, '') as 'Absent Penalty'," +
            "ISNULL(AdvanceTaken, '') as 'Advance Deducted', ISNULL(DeadlinesPenalty, '') as 'Deadlines Not Met', ISNULL(Gratuity, '') as 'Gratuity', " +
            "ISNULL(DeductionTotal, '') as 'Total Deduction' " +
            "FROM TeacherSalaries RIGHT JOIN Teachers ON TeacherSalaries.TeacherID = Teachers.ID " +
            "WHERE TeacherSalaries.MonthOfPayment LIKE '" + MonthComboBox.Text + "'";

            if (YearComboBox.Text != "")
            {
                query1 += " AND TeacherSalaries.YearOfPayment LIKE '"+ YearComboBox.Text +"'";
                query2 += " AND TeacherSalaries.YearOfPayment LIKE '" + YearComboBox.Text + "'";
                totalSalary = "SELECT TotalSalaries, TotalInitialSalaries FROM MonthlySalaries WHERE" +
                    " MonthOfPayment LIKE '" + MonthComboBox.Text + "' AND YearOfPayment LIKE '" + YearComboBox.Text + "'";
            }
            DbConnection d = new DbConnection();
            DataTable dt = d.Select(query1);
            DataTable dt2 = d.Select(query2);

            SalariesDataGridView.DataSource = dt;
            AdditionalSalaryDataGridView.DataSource = dt2;

            if (totalSalary != "")
            {
                dt = d.Select(totalSalary);
                for (int k = 0; k < dt.Rows.Count; k++)
                {
                    textBox1.Text = dt.Rows[k][0].ToString();
                }
            }

            label4.Visible = true;
            label5.Visible = true;
        }

        private void AddSalaryButton_Click(object sender, EventArgs e)
        {
            NewSalaryForm newForm = new NewSalaryForm(MonthComboBox.Text, YearComboBox.Text);
            newForm.Show();
        }

        private void ViewButton_Click(object sender, EventArgs e)
        {

            string query = "";
            try
            {
                query = "SELECT ID FROM Teachers WHERE NAME Like '"+
                SalariesDataGridView.SelectedRows[0].Cells[0].Value.ToString() +"'";
            }
            catch
            {
                MessageBox.Show("Please select a value!\n");
                return;
            }

            DbConnection d = new DbConnection();
            DataTable dt = d.Select(query);

            NewSalaryForm newForm = new NewSalaryForm(dt.Rows[0][0].ToString(), 
           SalariesDataGridView.SelectedRows[0].Cells[0].Value.ToString(),
           SalariesDataGridView.SelectedRows[0].Cells[2].Value.ToString(), 
           SalariesDataGridView.SelectedRows[0].Cells[3].Value.ToString(), true);

            newForm.Show();
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            string query = "";
            try
            {
                query = "SELECT ID FROM Teachers WHERE NAME Like '" +
                SalariesDataGridView.SelectedRows[0].Cells[0].Value.ToString() + "'";
            }
            catch
            {
                MessageBox.Show("Please select a value!\n");
                return;
            }

            DbConnection d = new DbConnection();
            DataTable dt = d.Select(query);

            NewSalaryForm newForm = new NewSalaryForm(dt.Rows[0][0].ToString(),
           SalariesDataGridView.SelectedRows[0].Cells[0].Value.ToString(),
           SalariesDataGridView.SelectedRows[0].Cells[2].Value.ToString(),
           SalariesDataGridView.SelectedRows[0].Cells[3].Value.ToString(), false);

            newForm.Show();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to permanently delete this record?", "Delete", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                string query = "";
                try
                {
                    query = "SELECT ID FROM Teachers WHERE NAME Like '" +
                    SalariesDataGridView.SelectedRows[0].Cells[0].Value.ToString() + "'";
                }
                catch
                {
                    MessageBox.Show("Please select a value!\n");
                    return;
                }

                DbConnection d = new DbConnection();
                DataTable dt = d.Select(query);

                string TeachID = dt.Rows[0][0].ToString();
                query = "DELETE FROM TeacherSalaries WHERE TeacherID LIKE '" + TeachID + "' AND MonthOfPayment " +
                "LIKE '" + SalariesDataGridView.SelectedRows[0].Cells[2].Value.ToString() + "' " +
                "AND YearOfPayment LIKE '" + SalariesDataGridView.SelectedRows[0].Cells[3].Value.ToString() + "'";

                d.Deletes(query);
                MessageBox.Show("Deleted!");
                
                //refresh form after deletion
                if(MonthComboBox.Text != "")
                {
                    MonthComboBox_SelectedIndexChanged(sender, e); 
                }
                else if(YearComboBox.Text != "")
                {
                    YearComboBox_SelectedIndexChanged(sender, e);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
                //do nothing
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            //refresh form
            MonthComboBox_SelectedIndexChanged(sender, e);

            YearComboBox_SelectedIndexChanged(sender, e);
        }
    }
}
