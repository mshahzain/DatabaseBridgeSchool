﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TheBridgeSchool
{
    public partial class AllTeachers : Form
    {
        public AllTeachers()
        {
            InitializeComponent();
        }

        private void AllTeachers_Load(object sender, EventArgs e)
        {   
            TeachersDataGridView.DataSource = null;
            TeachersDataGridView.Rows.Clear();

            string query = "SELECT ID, Name, FatherName as 'Father Name', Contact as 'Contact No.', " +
                "DOB as 'Date Of Birth', Qualification, DOJ as 'Date of Joining', ClassTeacherOf as 'Class Teacher', " +
                "Subject, Salary FROM Teachers";
            DbConnection d = new DbConnection();
            DataTable dt = d.Select(query);

            TeachersDataGridView.DataSource = dt;
        }

        private void NewTeachButton_Click(object sender, EventArgs e)
        {
            TeachersMainForm newForm = new TeachersMainForm("ADD");
            newForm.Show();
        }

        private void EditTeachBtton_Click(object sender, EventArgs e)
        {
            try
            {
                TeachersDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            }
            catch
            {
                MessageBox.Show("Please select a value!\n");
                return;
            }

            DbConnection d = new DbConnection();
            TeachersMainForm newForm = new TeachersMainForm("EDIT",TeachersDataGridView.SelectedRows[0].Cells[0].Value.ToString());

            newForm.Show();
        }

        private void DeleteTeachButton_Click(object sender, EventArgs e)
        {
            string TeachID = TeachersDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            DbConnection db = new DbConnection();
            string query = "DELETE FROM Teachers WHERE ID = '" + TeachID + "'";

            DialogResult dialog = MessageBox.Show("Are you sure you want to permanently delete all records of this person?", "Warning", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                try
                {
                    db.Deletes(query);
                    MessageBox.Show("Successfully deleted!");

                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            AllTeachers_Load(sender, e);
        }
    }
}
