﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TheBridgeSchool
{
    public partial class CashbookForm : Form
    {
        public CashbookForm()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            NewCashbookEntry newform = new NewCashbookEntry("INSERT");
            newform.Show();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                string query = "Delete From CashBookDaily where SerialNumber = '" 
                    + dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + "'";

                DbConnection d = new DbConnection();
               
                DialogResult dialog = MessageBox.Show("Are you sure?", "Delete", MessageBoxButtons.YesNo);

                if (dialog == DialogResult.Yes)
                {
                    try
                    {
                        d.Deletes(query);
                        MessageBox.Show("Deleted!");
                    }
                    catch(SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void MonthComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Reset form
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();

            //Fetch data
            string query1 = "SELECT * FROM CashBookDaily WHERE " +
                "CurrentTrackingMonth LIKE '" +MonthComboBox.Text+ "'";

            if (YearComboBox.Text != "")
            {
                query1 += " AND CashBookDaily.Year LIKE '" + YearComboBox.Text + "'";
            }
            DbConnection d = new DbConnection();
            DataTable dt = d.Select(query1);

            dataGridView1.DataSource = dt;
        }

        private void YearComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Reset form
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();

            //Fetch data
            string query1 = "SELECT * FROM CashBookDaily WHERE " +
                "CashBookDaily.Year LIKE '" + YearComboBox.Text + "'";

            if (MonthComboBox.Text != "")
            {
                query1 += " AND CurrentTrackingMonth LIKE '" + MonthComboBox.Text + "'";
            }
            DbConnection d = new DbConnection();
            DataTable dt = d.Select(query1);

            dataGridView1.DataSource = dt;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            //refresh form
            MonthComboBox_SelectedIndexChanged(sender, e);

            YearComboBox_SelectedIndexChanged(sender, e);
        }
    }
}
