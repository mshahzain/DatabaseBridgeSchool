﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TheBridgeSchool
{
    public partial class StudentsMainForm : Form
    {
        private string CurrentMode = "";
        private string savedOrnot = "No";

        private String name = "";
        private String Class = "";
        private String GrNo = "";
        private String F_Name = "";
        private String M_Name = "";
        private String Contact = "";
        private String DOB = "";
        private String Address = "";
        private String Attitude = "";


        public string selected = null;
        private string connectionString = null;
        SqlConnection cnn;

        public StudentsMainForm()
        {

            InitializeComponent();
            DisableAll();
            IDTextBox.Enabled = false;
            GradeComboBox.Text = "";
            GradeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        public StudentsMainForm(string Mode, string StID="")
        {
            InitializeComponent();
            CurrentMode = Mode;
            if (Mode == "ADD")
            {
                int id;
                button7.Text = "Add";
                IDTextBox.Enabled = false;
                EmptyAllTextBoxes();
                DbConnection db = new DbConnection();

                string query = "select top 1 ID from Students order by ID desc";
                id = db.IncrementID(query);

                if (id != -1)
                {
                    IDTextBox.Text = id.ToString();
                }
            }
            else if(Mode == "EDIT")
            {
                DbConnection db = new DbConnection();
                connectionString = db.GetConnectionString();
                cnn = new SqlConnection(connectionString);
                string Sql = "Select * from Students where ID like '" + StID + "'";
                cnn.Open();
                SqlCommand command = new SqlCommand(Sql, cnn);
                Console.WriteLine(Sql);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    IDTextBox.Text = reader.GetValue(0).ToString();
                    GrNo = IDTextBox.Text;
                    NameTextBox.Text = reader.GetValue(1).ToString();
                    name = NameTextBox.Text;
                    GradeComboBox.Text = reader.GetValue(2).ToString();
                    Class = GradeComboBox.Text;
                    FNameTextBox.Text = reader.GetValue(3).ToString();
                    F_Name = FNameTextBox.Text;
                    MNameTextBox.Text = reader.GetValue(6).ToString();
                    M_Name = MNameTextBox.Text;
                    ContactTextBox.Text = reader.GetValue(4).ToString();
                    Contact = ContactTextBox.Text;
                    if (reader.GetValue(5).ToString() == "")
                    { dateTimePickerBirthday.Value = Convert.ToDateTime("01/01/1999"); }
                    else { dateTimePickerBirthday.Value = Convert.ToDateTime(reader.GetValue(5).ToString()); }
                    DOB = dateTimePickerBirthday.Value.ToLongDateString();
                    AddrTextBox.Text = reader.GetValue(8).ToString();
                    Address = AddrTextBox.Text;
                    AttTextBox.Text = reader.GetValue(7).ToString();
                    Attitude = AttTextBox.Text;
                }

                cnn.Close();
            }

            else
            {
                MessageBox.Show("No Name Selected");
            }
        }
        private void DisableAll()
        {
            IDTextBox.Enabled = false;
            GradeComboBox.Enabled = false;
            NameTextBox.Enabled = false;
            FNameTextBox.Enabled = false;
            MNameTextBox.Enabled = false;
            ContactTextBox.Enabled = false;
            dateTimePickerBirthday.Enabled = false;
            AddrTextBox.Enabled = false;
            AttTextBox.Enabled = false;
           
            button7.Enabled = false;
        }
        private void EnableAll()
        {
            //textBox2.Enabled = true;
            GradeComboBox.Enabled = true;
            NameTextBox.Enabled = true;
            FNameTextBox.Enabled = true;
            MNameTextBox.Enabled = true;
            ContactTextBox.Enabled = true;
            dateTimePickerBirthday.Enabled = true;
            AddrTextBox.Enabled = true;
            AttTextBox.Enabled = true;
            
            button7.Enabled = true;
        }
        private void EmptyAllTextBoxes()
        {
            GradeComboBox.Text = "";
            IDTextBox.Text = "";
            NameTextBox.Text = "";
            FNameTextBox.Text = "";
            MNameTextBox.Text = "";
            ContactTextBox.Text = "";
            dateTimePickerBirthday.Value = Convert.ToDateTime("01/01/1999");
            AddrTextBox.Text = "";
            AttTextBox.Text = "";
        }
       
        private bool CheckIfChanged()
        {
            if (GrNo == IDTextBox.Text)
            {
                if (name == NameTextBox.Text)
                {
                    if (Class == GradeComboBox.Text)
                    {
                        if (F_Name == FNameTextBox.Text)
                        {
                            if (M_Name == MNameTextBox.Text)
                            {
                                if (Contact == ContactTextBox.Text)
                                {
                                    if (DOB == dateTimePickerBirthday.Value.ToLongDateString())
                                    {
                                        if (Address == AddrTextBox.Text)
                                        {
                                            if (Attitude == AttTextBox.Text)
                                            {
                                                return false;
                                            }
                                        }
                                    }
                                }

                            }
                        }

                    }
                }
            }
            return true;
                
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            if (GradeComboBox.Text != "" && NameTextBox.Text != "")
            {
                if (CurrentMode == "EDIT")
                {
                    string updateQuery =  "UPDATE Students Set StudentName ='" + NameTextBox.Text +
                        "',Class ='" +  GradeComboBox.Text + "', FatherName ='" + FNameTextBox.Text + "', MotherName ='" +
                   MNameTextBox.Text + "',ContactNo ='" + ContactTextBox.Text + "' ,DOB ='" + dateTimePickerBirthday.Value.Date.ToString("yyyy/MM/dd HH:mm:ss")
                   + "' , Attitude ='" + AttTextBox.Text + "' ,Address ='" + AddrTextBox.Text + 
                   "' WHERE ID = '" + IDTextBox.Text + "'";

                    DbConnection db = new DbConnection();
                    try
                    {
                        db.Update(updateQuery);
                        savedOrnot = "Yes";
                        MessageBox.Show("Successfully updated!");
                        this.Close();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                else if (CurrentMode == "ADD")
                {
                    DbConnection db = new DbConnection();

                    string addQuery = "Insert into Students (ID, StudentName, FatherName, Class, ContactNo, DOB, MotherName, " +
                        "Attitude, Address) VALUES('" + IDTextBox.Text + "', '" + NameTextBox.Text +
                        "', '" + FNameTextBox.Text + "', '" + GradeComboBox.Text + "', '"
                        + ContactTextBox.Text + "', '" + dateTimePickerBirthday.Value.Date.ToString("yyyy/MM/dd HH:mm:ss")
                        + "', '" + MNameTextBox.Text + "', '" + AttTextBox.Text + "', '" + AddrTextBox.Text + "')";

                    try
                    {
                        db.Inserts(addQuery);
                        savedOrnot = "Yes";
                        MessageBox.Show("Successfully added!");
                        this.Close();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("The Name and Class field can not be left empty");
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        { 
            this.Close();   
        }

        private void Form4_Form_Closing(object sender, FormClosingEventArgs e)
        {
            if (savedOrnot == "No")
            {
                if (CheckIfChanged())
                {
                    DialogResult dialog = MessageBox.Show("Do you really want to close this, without saving?", "Warning", MessageBoxButtons.YesNo);
                    if (dialog == DialogResult.Yes)
                    {
                        e.Cancel = false;
                    }
                    else
                    {
                        e.Cancel = true;
                    }
                }
            }
        }
    }
}

