﻿namespace TheBridgeSchool
{
    partial class AllTeachers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AllTeachers));
            this.TeachersDataGridView = new System.Windows.Forms.DataGridView();
            this.DeleteTeachButton = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.EditTeachBtton = new System.Windows.Forms.Button();
            this.NewTeachButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TeachersDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // TeachersDataGridView
            // 
            this.TeachersDataGridView.AllowUserToAddRows = false;
            this.TeachersDataGridView.AllowUserToDeleteRows = false;
            this.TeachersDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.TeachersDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.TeachersDataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.TeachersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TeachersDataGridView.Location = new System.Drawing.Point(14, 39);
            this.TeachersDataGridView.Name = "TeachersDataGridView";
            this.TeachersDataGridView.ReadOnly = true;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.TeachersDataGridView.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.TeachersDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.TeachersDataGridView.Size = new System.Drawing.Size(812, 331);
            this.TeachersDataGridView.TabIndex = 9;
            // 
            // DeleteTeachButton
            // 
            this.DeleteTeachButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DeleteTeachButton.BackgroundImage")));
            this.DeleteTeachButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DeleteTeachButton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.DeleteTeachButton.Location = new System.Drawing.Point(558, 379);
            this.DeleteTeachButton.Name = "DeleteTeachButton";
            this.DeleteTeachButton.Size = new System.Drawing.Size(131, 27);
            this.DeleteTeachButton.TabIndex = 13;
            this.DeleteTeachButton.Text = "Delete Record";
            this.DeleteTeachButton.UseVisualStyleBackColor = true;
            this.DeleteTeachButton.Click += new System.EventHandler(this.DeleteTeachButton_Click);
            // 
            // button3
            // 
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button3.Location = new System.Drawing.Point(14, 379);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(122, 27);
            this.button3.TabIndex = 12;
            this.button3.Text = "Back";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // EditTeachBtton
            // 
            this.EditTeachBtton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("EditTeachBtton.BackgroundImage")));
            this.EditTeachBtton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.EditTeachBtton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.EditTeachBtton.Location = new System.Drawing.Point(695, 379);
            this.EditTeachBtton.Name = "EditTeachBtton";
            this.EditTeachBtton.Size = new System.Drawing.Size(131, 27);
            this.EditTeachBtton.TabIndex = 11;
            this.EditTeachBtton.Text = "Edit Record";
            this.EditTeachBtton.UseVisualStyleBackColor = true;
            this.EditTeachBtton.Click += new System.EventHandler(this.EditTeachBtton_Click);
            // 
            // NewTeachButton
            // 
            this.NewTeachButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("NewTeachButton.BackgroundImage")));
            this.NewTeachButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.NewTeachButton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.NewTeachButton.Location = new System.Drawing.Point(157, 379);
            this.NewTeachButton.Name = "NewTeachButton";
            this.NewTeachButton.Size = new System.Drawing.Size(174, 27);
            this.NewTeachButton.TabIndex = 10;
            this.NewTeachButton.Text = "Add New Teacher";
            this.NewTeachButton.UseVisualStyleBackColor = true;
            this.NewTeachButton.Click += new System.EventHandler(this.NewTeachButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.Color.SeaShell;
            this.label6.Location = new System.Drawing.Point(751, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(148, 26);
            this.label6.TabIndex = 22;
            this.label6.Text = "🔄 REFRESH";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // AllTeachers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(842, 418);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.DeleteTeachButton);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.EditTeachBtton);
            this.Controls.Add(this.NewTeachButton);
            this.Controls.Add(this.TeachersDataGridView);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Maroon;
            this.Name = "AllTeachers";
            this.Text = "AllTeachers";
            this.Load += new System.EventHandler(this.AllTeachers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TeachersDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView TeachersDataGridView;
        private System.Windows.Forms.Button DeleteTeachButton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button EditTeachBtton;
        private System.Windows.Forms.Button NewTeachButton;
        private System.Windows.Forms.Label label6;
    }
}