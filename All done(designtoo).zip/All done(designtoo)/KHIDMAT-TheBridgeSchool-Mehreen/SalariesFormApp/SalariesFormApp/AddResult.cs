﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheBridgeSchool
{
    public partial class AddResult : Form
    {
        public AddResult()
        {
            InitializeComponent();
        }

        private string GradeValue(string gradeName)
        {
            string shortForm = "";
            if (gradeName == "Play Group")
            {
                shortForm = "PG";
            }
            else if (gradeName == "Lower Nursery")
            {
                shortForm = "LNY";
            }
            else if (gradeName == "Lower Nursery B")
            {
                shortForm = "LNB";
            }
            else if (gradeName == "1A")
            {
                shortForm = "1A";
            }
            else if (gradeName == "1B")
            {
                shortForm = "1B";
            }
            else if (gradeName == "2nd")
            {
                shortForm = "2A";
            }
            else if (gradeName == "3rd")
            {
                shortForm = "3A";
            }
            else if (gradeName == "4th")
            {
                shortForm = "4A";
            }
            else if (gradeName == "5th")
            {
                shortForm = "5A";
            }
            else if (gradeName == "6th")
            {
                shortForm = "6A";
            }
            else if (gradeName == "7th")
            {
                shortForm = "7A";
            }
            else if (gradeName == "8th")
            {
                shortForm = "8A";
            }
            return shortForm;
        }

        private void AddResult_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'khidmatDataSet.Results' table. You can move, or remove it, as needed.
            //this.resultsTableAdapter.Fill(this.khidmatDataSet.Results);

        }

        private void AddDataToComboBox()
        {
            DbConnection db = new DbConnection();

            string Sql = "Select StudentName from Students where Class like '" + GradeValue(ClassComboBox.Text) + "' Order by StudentName";

            db.conn.Open();
            db.cmd.CommandText = Sql;
            db.cmd.Connection = db.conn;
            SqlDataReader reader = db.cmd.ExecuteReader();
            while (reader.Read())
            {
                NameComboBox.Items.Add(reader.GetValue(0).ToString());
            }
            //db.cmd.ExecuteNonQuery();
            db.conn.Close();
        }

        private void AddDataToSubComboBox()
        {
            DbConnection db = new DbConnection();

            string Sql = "Select distinct Subject from Results where Class like '" + GradeValue(ClassComboBox.Text) + "' Order by Subject";

            db.conn.Open();
            db.cmd.CommandText = Sql;
            db.cmd.Connection = db.conn;
            SqlDataReader reader = db.cmd.ExecuteReader();
            while (reader.Read())
            {
                SubComboBox.Items.Add(reader.GetValue(0).ToString());
            }

            db.conn.Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ClassComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            NameComboBox.Items.Clear();
            AddDataToComboBox();
            SubComboBox.Items.Clear();
            AddDataToSubComboBox();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            DbConnection d = new DbConnection();
            string studentIDQUERY = "SELECT ID FROM Students WHERE Students.StudentName LIKE '" + NameComboBox.Text + "'";
            DataTable dt2 = d.Select(studentIDQUERY);
            string studentID = dt2.Rows[0][0].ToString();
            MessageBox.Show(dateTimePicker1.Value.Date.ToString("yyyy/MM/dd HH:mm:ss"));

            d.Inserts("INSERT INTO Results (ID, Class, Subject, Description, Date, TotalMarks, MarksObtained) " +
                "VALUES(" + studentID + ", '" + GradeValue(ClassComboBox.Text) + "', '" + SubComboBox.Text + "', '" + textBox5.Text + "', '" +
                dateTimePicker1.Value.Date.ToString("yyyy/MM/dd HH:mm:ss") + "', '" + textBox7.Text + "', '" + textBox8.Text + "')");
            this.Hide();
            MessageBox.Show("New Record Added!");
        }

        private void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsControl(e.KeyChar) && !Char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter a valid value.");
            }
        }

        private void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsControl(e.KeyChar) && !Char.IsLetterOrDigit(e.KeyChar) && e.KeyChar != 45)
            {
                e.Handled = true;
                MessageBox.Show("You can enter letters, numbers and '-' only.");
            }
        }

        private void TextBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter a valid value.");
            }
        }

        private void TextBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Please enter a valid value.");
            }
        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Label7_Click(object sender, EventArgs e)
        {

        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }
    }
}
